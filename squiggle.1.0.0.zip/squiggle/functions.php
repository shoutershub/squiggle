<?php

/*******************************************
#  Squiggle functions and definitions
#  @link https://developer.wordpress.org/themes/basics/theme-functions/
#  @package Squiggle
#  Please make a backup before you change or edit any function
*******************************************/


if ( ! function_exists( 'squiggle_setup' ) ) :

        /*******************************************
        #  Sets up theme defaults and registers support for various WordPress features.
        #  Note that this function is hooked into the after_setup_theme hook, which
        #  runs before the init hook. The init hook is too late for some features, such
        #  as indicating support for post thumbnails.
        *******************************************/

	function squiggle_setup() {
        
         require_once ('inc/plugins/class-tgm-activaton.php');
         include_once ('options/meta-box.php');
         include_once ('inc/widgets/post-countdown.php');
         include_once ('inc/widgets/fresh-post.php');
         include_once ('inc/widgets/cat-widget.php');
         include_once ('inc/widgets/widgets.php');
         include_once ('inc/wellcome.php');

        /*******************************************
        #  Make theme available for translation.
        #  Translations can be filed in the /languages/ directory.
        #  If you're building a theme based on Squiggle
        #  use a find option in your IDE or text-editor and replace
        #  to change 'squiggle' to the name of your theme in all the template files.
        *******************************************/
        
		load_theme_textdomain( 'squiggle', get_template_directory() . '/languages' );

        /*******************************************
        #  Add default posts and comments RSS feed links to head.
        *******************************************/
        
		add_theme_support( 'automatic-feed-links' );
        
        /*******************************************
        #  Let WordPress manage the document title.
        #  By adding theme support, we declare that this theme does not use a
        #  hard-coded <title> tag in the document head, and expect WordPress to
        #  provide it for us.
        *******************************************/
        
		add_theme_support( 'title-tag' );

        /*******************************************
        #  Enable support for Post Thumbnails on posts and pages.
        #  @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
        *******************************************/
        
		add_theme_support( 'post-thumbnails' );
        
        
        /*******************************************
        #  This theme uses wp_nav_menu() in one location. 
        #  see template-parts/header/header-1.php, header-2.php ect.
        *******************************************/

		register_nav_menus( array(
			'main-menu' => esc_html__( 'Main menu', 'squiggle' ),
		) );

        /*******************************************
        #  Switch default core markup for search form, comment form, and comments
        #  to output valid HTML 5
        *******************************************/
        
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );


        /*******************************************
        #  Set up the WordPress core custom background feature.
        *******************************************/
        
		add_theme_support( 'custom-background', apply_filters( 'squiggle_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

        /*******************************************
        #  Add theme support for selective refresh for widgets.
        *******************************************/
        
		add_theme_support( 'customize-selective-refresh-widgets' );

        
        /*******************************************
        #  Add support for core custom logo.
        #  @link https://codex.wordpress.org/Theme_Logo.
        *******************************************/
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'squiggle_setup' );

/*******************************************
#  Set the content width in pixels, based on the theme's design and stylesheet.
#  @global int $content_width.
#  Priority 0 to make it available to lower priority callbacks.
*******************************************/

function squiggle_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'squiggle_content_width', 640 );
}
add_action( 'after_setup_theme', 'squiggle_content_width', 0 );


/*******************************************
#  Enquee Theme Scripts and Styles
*******************************************/

function squiggle_scripts() {
    
	wp_enqueue_style( 'squiggle-font','https://fonts.googleapis.com/css?family=Coustard|Open+Sans:400,700');
	wp_enqueue_style( 'squiggle-font','https://fonts.googleapis.com/css?family=Coustard|Open+Sans:400,700');
	wp_enqueue_style( 'squiggle-bootstrap-style', get_template_directory_uri() . '/asset/css/bootstrap.css' );
	wp_enqueue_style( 'squiggle-style', get_stylesheet_uri() );
	wp_enqueue_style( 'squiggle-fontawesome-icons', get_template_directory_uri() . '/asset/font-awesome/css/font-awesome.css' );
	wp_enqueue_script( 'squiggle-google-jq', get_template_directory_uri() . '/asset/js/googlejq.js', array(), '20151215', true );
	wp_enqueue_script( 'squiggle-bootstrap-script', get_template_directory_uri() . '/asset/js/bootstrap.min.js', array(), '20151215', true );
	wp_enqueue_script( 'squiggle-custom-script', get_template_directory_uri() . '/asset/js/custom.js', array(), '20151215', true );
    

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'squiggle_scripts' );


function remove_default_stylesheet() {
    
    if (  get_theme_mod('sq_rtl_setting') == true ) { 
    wp_enqueue_style( 'squiggle-rtl', get_template_directory_uri() . '/asset/css/rtl.css' ); 
    wp_register_style( 'squiggle-rtl', get_template_directory_uri() . '/asset/css/rtl.css'); 
    wp_enqueue_style( 'squiggle-rtl' );
        wp_dequeue_style( 'squiggle-style', get_stylesheet_uri() );
            wp_deregister_style( 'squiggle-style' );
    } else {
        wp_dequeue_style( 'squiggle-rtl' );
    }; 
        
    
}

add_action( 'wp_enqueue_scripts', 'remove_default_stylesheet', 20 );



/*******************************************
#  Sharpen Resized Image on chome and older browser - you would love it
*******************************************/

function ajx_sharpen_resized_files( $resized_file ) {

    $image = wp_get_image_editor( $resized_file );
    if ( !is_resource( $image ) )
        return new WP_Error( 'error_loading_image', $image, $file );

    $size = @getimagesize( $resized_file );
    if ( !$size )
        return new WP_Error('invalid_image', __('Could not read image size', 'squiggle'), $file);
    list($orig_w, $orig_h, $orig_type) = $size;

    switch ( $orig_type ) {
        case IMAGETYPE_JPEG:
            $matrix = array(
                array(-1, -1, -1),
                array(-1, 16, -1),
                array(-1, -1, -1),
            );

            $divisor = array_sum(array_map('array_sum', $matrix));
            $offset = 0; 
            imageconvolution($image, $matrix, $divisor, $offset);
            imagejpeg($image, $resized_file,apply_filters( 'jpeg_quality', 90, 'edit_image' ));
            break;
        case IMAGETYPE_PNG:
            return $resized_file;
        case IMAGETYPE_GIF:
            return $resized_file;
    }

    return $resized_file;
}   

add_filter('image_make_intermediate_size', 'ajx_sharpen_resized_files',900);


/*******************************************
#  Stop Self Pinging
*******************************************/

function no_self_ping( &$links ) {
    $home = home_url();
    foreach ( $links as $l => $link )
        if ( 0 === strpos( $link, $home ) )
            unset($links[$l]);
}
add_action( 'pre_ping', 'no_self_ping' );


/*******************************************
#  Thumbnail size and functionality
*******************************************/

	add_image_size( 'sq-big', 280, 390, true, array( 'center', 'center' ) );
	add_image_size( 'sq-small-thumb', 280, 390, true, array( 'center', 'center' ) );
	add_image_size( 'carosel-thumb', 310, 210, true, array( 'center', 'center' ) );
	add_image_size( 'sq-related-thumbnail', 210, 200, true, array( 'center', 'center' ) );
	add_image_size( 'sq-even-more-thumb', 259, 145, true, array( 'center', 'center' ) );
	add_image_size( 'grid-1-thumbnail', 340, 300, true, array( 'center', 'center' ) );
	add_image_size( 'sq-full-width-thumb', 964, 280 );

/*******************************************
#  Excerpt Functionality
*******************************************/

	function wpdocs_custom_excerpt_length( $length ) {
		return 30;
	}
	add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );
	function wpdocs_excerpt_more( $more ) {
		return '...';
	}
	add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );



/*******************************************
#  Author Social Profile
*******************************************/

function squiggle_social_profile($profile_fields) {

	// Add new fields
	$profile_fields['facebook'] = 'Facebook URL (with http://)';
	$profile_fields['gplus'] = 'Google+ URL';
    $profile_fields['twitter'] = 'Twitter URL';
	$profile_fields['github'] = 'Github URL';
	$profile_fields['youtube'] = 'Youtube URL';
	return $profile_fields;
}

add_filter('user_contactmethods', 'squiggle_social_profile');


/*******************************************
#  Custom Comments template
*******************************************/

function squiggle_comments( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment; ?>
    <li <?php comment_class(); ?> id="li-comment-
        <?php comment_ID() ?>">
        <div id="comment-<?php comment_ID(); ?>" itemprop="comment" itemscope itemtype="http://schema.org/UserComments">
            <div class="comment-author vcard">
                <?php echo get_avatar( $comment->comment_author_email, 90 ); ?>
                <div class="body-relative-class" style="position: relative;">
                    <div class="the-whole-post-body">
                        <?php printf( '<span class="fn" itemprop="creator" itemscope itemtype="http://schema.org/Person"><span itemprop="name">%s</span></span>', get_comment_author_link() ) ?>
                        <?php if ( ! empty( $squiggle_options['squiggle_comment_date'] ) ) { ?> <span class="ago"><?php comment_date( get_option( 'date_format' ) ); ?></span>
                        <?php } ?> <span class="comment-meta">
                    <?php edit_comment_link( __( '( Edit )', 'squiggle' ), '  ', '' ) ?>
                </span>
                        <?php if ( $comment->comment_approved == '0' ) : ?> <em><?php _e( 'Your comment is awaiting moderation.', 'squiggle' ) ?></em>
                        <br />
                        <?php endif; ?>
                        <div class="commentmetadata">
                            <div class="commenttext" itemprop="commentText">
                                <?php comment_text() ?> <span class="reply">
                        <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] )) ) ?>
                    </span> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </li>
    <?php }

/*******************************************
# Breadcrumbs on hook system with rich snippet
*******************************************/

if ( !function_exists('get_breadcrumb') ) {
function get_breadcrumb() {
	global $post;
	if( is_front_page() )
		return;
		if (class_exists('bbPress') && is_bbpress()) :
			bbp_breadcrumb();
		else :
		echo '<div class="breadcrumb-wrap" xmlns:v="http://rdf.data-vocabulary.org/#"><div class="inner-breadcrumb">';
		echo '<i class="fa fa-home"></i> <span typeof="v:Breadcrumb"><a href="';
        echo home_url();
        echo '" rel="v:url" property="v:title">';
        echo __('Home','squiggle');
        echo "</a></span> <i class=\"fa fa-chevron-right\"></i>";
        if (is_category()) {
			global $wp_query;
            $cat_obj = $wp_query->get_queried_object();
            $thisCat = $cat_obj->term_id;
            $thisCat = get_category($thisCat);
            $parentCat = get_category($thisCat->parent);
            if ( $thisCat->parent != 0 ) {
				echo '<span typeof="v:Breadcrumb"><a href="';
                echo get_category_link( $parentCat->term_id );
				echo '" rel="v:url" property="v:title">';
				echo $parentCat->name;
				echo "</a></span>";
				}
		echo '<span property="v:title">';
			echo sprintf( __( 'Archive by category "%s"', 'squiggle' ), single_cat_title( '', false ) );
		echo '</span>';
        } elseif (is_post_type_archive()) {
		echo '<span property="v:title">';
			echo post_type_archive_title();
		echo '</span>';
        }  elseif (is_single()) {
		$category = get_the_category();
		foreach($category as $category) {
		echo '<span typeof="v:Breadcrumb"><a href="';
			echo get_category_link($category->term_id);
		echo '" rel="v:url" property="v:title">' . $category->name . '</a></span>';
			}
                echo '<span property="v:title">' . get_the_title() . '</span>';
		} elseif (is_page()) {
                echo '<span property="v:title">' . get_the_title() . '</span>';
        }
		elseif (is_tag()) {
                echo '<span property="v:title">';
					echo single_tag_title();
				echo '</span>';
				}
		elseif (is_day()) {echo '<span property="v:title">' . __("Archive for ",'squiggle') . get_the_time('F jS, Y') . '</span>';}
		elseif (is_month()) {echo '<span property="v:title">' . __("Archive for ",'squiggle') . get_the_time('F, Y') . '</span>';}
		elseif (is_year()) {echo '<span property="v:title">' . __("Archive for ",'squiggle') . get_the_time('Y') . '</span>';}
		elseif (is_author()) {echo '<span property="v:title">' . __("Author Archive",'squiggle') . '</span>';}
		elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {echo '<span property="v:title">' . __("Blog Archives",'squiggle') . '</span></li>';}
		elseif (is_search()) {echo '<span property="v:title">' . __("Search Results",'squiggle') . '</span>';}
		elseif (is_404()) {echo '<span property="v:title">' . __("Page not found",'squiggle') . '</span>';}
		echo '</div></div>';
		endif;
	}
add_action('get_breadcrumb', 'get_breadcrumb' );
}


/*******************************************
# Customizer theme option
*******************************************/

require get_template_directory() . '/inc/customizer.php';


/*******************************************
# ads after x number of paragrah
*******************************************/


function insert_ad_block( $text ) {
    
    
    $inpost_ads_count = get_theme_mod('sq_allow_inlinepost_ads_count');
    $inpost_ads = get_theme_mod('sq_allow_inlinepost_ads');
    

    if ( is_single() ) :
		$new_text = '';
        $ads_text = '<div class="inpost-ads img-is-responsive">' . $inpost_ads .  '</div>';
        $split_by = "\n";
        $insert_after = $inpost_ads_count; //number of paragraphs

        // make array of paragraphs
        $paragraphs = explode( $split_by, $text);

        // if array elements are less than $insert_after set the insert point at the end
        $len = count( $paragraphs );
        if (  $len < $insert_after ) $insert_after = $len;

        // insert $ads_text into the array at the specified point
        array_splice( $paragraphs, $insert_after, 0, $ads_text );

        // loop through array and build string for output
        foreach( $paragraphs as $paragraph ) {
            $new_text .= $paragraph; 
        }

        return $new_text;

    endif;

    return $text;

}
add_filter('the_content', 'insert_ad_block');

/*******************************************
# Apply theme's stylesheet to the visual editor.
*******************************************/

add_action( 'init', 'cd_add_editor_styles' );
/**
 *
 * @uses add_editor_style() Links a stylesheet to visual editor
 * @uses get_stylesheet_uri() Returns URI of theme stylesheet
 */
function cd_add_editor_styles() {
 add_editor_style( get_stylesheet_uri() );
}


/*******************************************
# Demo import function
*******************************************/

include ('inc/demo-files/demo-function.php');

/*******************************************
#  You can add any custom function below this line
#  Remeber to tie in the text_domain 'squiggle'
#  see the guide @ https://make.wordpress.org/polyglots/handbook/ 
#  and also https://translate.wordpress.org
*******************************************/


