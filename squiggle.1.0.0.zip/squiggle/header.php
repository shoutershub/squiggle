<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Squiggle
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <?php wp_head(); ?>
        <script>
            <?php echo get_theme_mod('sq_custom_js') ?>
        </script>
</head>
    <!--Body Tag-->

<body <?php body_class(); ?>>
    <div id="page" class="site">
        <div class="squiggle-main-sect">
            <div class="container">
                <!-- Whole page Container Tag -->
                <?php if (  get_theme_mod('nav_type_select', 1 ) == 1 ) { ?>
                    <?php include get_template_directory() . '/template-parts/header/header-1.php'?>
                        <?php } else { ?>
                            <?php include get_template_directory() . '/template-parts/header/header-2.php'?>
                                <?php } ?>
                                    <div id="content" class="site-content">