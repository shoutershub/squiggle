<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Squiggle
 */

get_header(); ?>
    <div class="col-md-12 no-padding clearfix">
        <div class="col-md-8 col-sm-8">
            <button class="Squiggle-button">
                <?php
                    /* translators: %s: search query. */
                    printf( esc_html__( 'Search Results for: %s', 'squiggle' ), '<span>' . get_search_query() . '</span>' );
                        ?> </button>
            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <div class="main-post-loop">
                    <div class="big-thum-section img-is-responsive">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail('small-block-thumb'); ?>
                                <?php endif; ?>
                    </div>
                    <div class="squiggle-post-meta-section clearfix">
                        <h2><a href="<?php echo get_permalink(); ?>"> <?php the_title(); ?> </a></h2>
                        <p class="excerpt-post">
                            <?php the_excerpt(); ?>
                        </p>
                    </div>
                    <div class="continue-reading-section"> <a href="<?php echo get_permalink(); ?>" class="cont-reading"> Continue reading <i class="fa fa-chevron-right"></i></a> </div>
                    <div class="squiggly-line"></div>
                </div>
                <?php endwhile; else: ?>
                    <div class="error-404 not-found">
                        <header class="page-header">
                            <h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'squiggle' ); ?></h1> </header>
                        <!-- .page-header -->
                        <div class="page-content">
                            <p>
                                <?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'squiggle' ); ?>
                            </p>
                        </div>
                        <!-- .page-content -->
                    </div>
                    <!-- .error-404 -->
                    <?php endif; ?>
                        <?php
                        the_posts_pagination( array(
                            'mid_size' => 2,
                            'prev_text' => esc_html( '&larr;' ),
                            'next_text' => esc_html( '&rarr;' ),
                        ) );
                    ?>
        <!--End Pagination-->
        </div>
        <div class="col-md-4 col-sm-4">
            <?php  get_sidebar(); ?>
        </div>
    </div>
    <?php

get_footer();