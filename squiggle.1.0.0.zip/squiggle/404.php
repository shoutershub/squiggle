<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Squiggle
 */

get_header(); ?>
    <div class="col-md-12 no-padding clearfix">
        <div class="col-md-8 col-sm-8">
            <div class="page-content">
                <div class="nothing-found">
                    <div class="no-page-found text-center">
                        <h1><?php _e('404','squiggle') ?></h1>
                        <p><?php _e('Nothing seems to be found here', 'squiggle'); ?></p>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                            <button><i class="fa fa-home" style="padding-right: 10px;"></i>
                                <?php _e('Take me home', 'squiggle'); ?>
                            </button>
                        </a>
                    </div>
                </div>
            </div>
            <!-- .page-content -->
        </div>
        <div class="col-md-4 col-sm-4">
            <?php get_sidebar(); ?>
        </div>
    </div>
    <?php
get_footer();
