<?php
     $related = get_posts( array( 'category__in' => wp_get_post_categories($post->ID), 'orderby' => 'rand', 'numberposts' => 1, 'post__not_in' => array($post->ID) ) ); if( $related ) foreach( $related as $post ) { setup_postdata($post); ?>
    <div class="even-more-sq-rt">
        <h3><b><?php _e('Trending Now', 'squiggle');?></b></h3>
        <button id="close-even-more" class="close-btn" title="<?php _e('close', 'squiggle'); ?>">X</button>
        <div class="even-more-sq-rt-inner clearfix">
           <a href="<?php get_permalink(); ?>">
            <div class="even-more-sq-rt-thumb img-responsive">
                <?php if ( has_post_thumbnail() ) : ?>
                    <?php the_post_thumbnail('sq-even-more-thumb'); ?>
                        <?php else : ?> <img src="<?php echo get_template_directory_uri(); ?>/asset/img/no-medium-thumb.png">
                            <?php endif; ?>
            </div>
            <div class="even-more-sq-rt-postmeta">
                <p>
                    <?php the_title() ?>
                </p>
            </div>
            </a>
        </div>
    </div>
    <?php } wp_reset_postdata(); ?>