<div class="sq-share-buttons col-md-12"> <span class="share-buttons"><?php echo _e('Share', 'squiggle');?> </span>
    <a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" title="<?php echo _e('Share This Post on Facebook !', 'squiggle');?>" onclick="window.open(this.href); return false;" rel="nofollow">
        <button class="post-share-btn  facbook-share"><i class="fa fa-facebook"></i> <span class="hidden-xs"><?php echo _e('Facebook', 'squiggle');?></span> </button>
    </a>
    <a href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink(); ?>" title="<?php echo _e('Share This Post on Twitter !', 'squiggle');?>" target="_blank" rel="nofollow">
        <button class="post-share-btn twitter-share"><i class="fa fa-twitter"></i> <span class="hidden-xs"><?php echo _e('Twitter', 'squiggle');?></span> </button>
    </a>
    <a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href,
  '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" rel="nofollow" title="<?php echo _e('Share This Post on Google+ !', 'squiggle');?>">
        <button class="post-share-btn google-share"><i class="fa fa-google-plus"></i> <span class="hidden-xs"><?php echo _e('Google +', 'squiggle');?></span> </button>
    </a>
    <a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>" title="<?php echo _e('Share This Post on Twitter !', 'squiggle');?>">
        <button class="post-share-btn pinterest-share"><i class="fa fa-pinterest"></i> <span class="hidden-xs"><?php echo _e('Pinterest', 'squiggle');?></span> </button>
    </a>
</div>