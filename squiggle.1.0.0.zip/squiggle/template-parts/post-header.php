<div class="single-post-header-wrapper">
    <h1 class="single-post-title"> <?php the_title(); ?> </h1>
    <div class="other-post-meta">
        <?php if (  get_theme_mod('sq_single_shw_post_rdate', true ) == true ) { ?><span class="bold"> Posted on </span>
            <?php the_time('jS M, Y'); ?>
                <?php } ?>
                    <?php if (  get_theme_mod('sq_single_shw_post_author', true ) == true ) { ?><span class="bold">By: <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></span>
                        <?php } ?>
                            <?php if (  get_theme_mod('sq_single_shw_post_cate', true ) == true ) { ?> <span class="bold"></span>
                                <?php $category = get_the_category(); if ($category) 
                            { echo wp_kses_post('<a href="' . get_category_link( $category[0]->term_id ) . '" class="single-post-cat" title="' . sprintf( esc_html__( "View all posts in %s", "Squiggle" ), $category[0]->name ) . '" ' . '>' . $category[0]->name.'</a> ');}  ?>
                                    <?php } ?>
                                        <?php if (  get_theme_mod('sq_single_shw_post_comments_count', true ) == true ){ ?> <span class="single-comment"><i class="fa fa-comments"> </i> <?php comments_number( '0', '1', '% responses' ); ?>
                      </span>
                                            <?php } ?>
    </div>
</div>