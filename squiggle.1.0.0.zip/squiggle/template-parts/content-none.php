<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Squiggle
 */

?>
    <section class="no-results not-found">
        <header class="page-header">
            <h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'squiggle' ); ?></h1> </header>
        <!-- .page-header -->
        <div class="page-content">
            <div class="nothing-found">
                <div class="text-center">
                    <h1> <?php _e('404','squiggle') ?> </h1>
                    <p> <?php _e('Nothing seems to be found fr your search term','squiggle') ?> </p>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                        <button class="Squiggle-button"><i class="fa fa-home"></i><?php _e('Take me home', 'squiggle');?></button>
                    </a>
                </div>
            </div>
        </div>
        <!-- .page-content -->
    </section>
    <!-- .no-results -->