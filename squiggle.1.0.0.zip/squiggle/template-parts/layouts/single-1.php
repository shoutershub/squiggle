<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Squiggle
 */

?>
    <article class="clearfix" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <div class="single-post-inner">
            <?php if(current_user_can('administrator')){ ?>
                <div class="single-post-edit">
                    <a href="<?php  echo esc_url( home_url() );?>/wp-admin/post.php?post=<?php the_ID(); ?>&action=edit">
                        <button><i class="fa fa-cog"></i> Edit Post </button>
                    </a>
                </div>
                <?php } ?>
                    <?php get_template_part( 'template-parts/bread', 'crumb' ); ?>
                        <?php get_template_part( 'template-parts/post', 'header' ); ?>
                            <div class="the-main-post-content">
                                <?php the_content(); ?>
                            </div>
                            <?php if (  get_theme_mod('sq_single_shw_post_share_btn', true ) == true ) { ?>
                                <?php get_template_part( 'template-parts/social', 'share' ); ?>
                                    <?php } ?>
                                        <div class="col-md-12 widgets-container">
                                            <?php dynamic_sidebar( 'sidebar-6');  ?>
                                        </div>
                                        <?php if (  get_theme_mod('sq_single_shw_post_post_navi', true ) == true ) { ?>
                                            <?php get_template_part( 'template-parts/post', 'navi' ); ?>
                                                <?php } ?>
                                                    <?php if (  get_theme_mod('sq_single_shw_post_related_post', true ) == true ) { ?>
                                                        <?php get_template_part( 'template-parts/related', 'post' ); ?>
                                                            <?php } ?>
                                                                <?php if (  get_theme_mod('sq_single_shw_post_post_author_box', true ) == true ) { ?>
                                                                    <?php get_template_part( 'template-parts/author', 'box' ); ?>
                                                                        <?php } ?>
                                                                            <?php if (  get_theme_mod('sq_single_shw_post_post_tag', true ) == true ) { ?>
                                                                                <div class="sq-single-tags clearfix">
                                                                                    <?php
                if(get_the_tag_list()) {
                echo get_the_tag_list('<button class="smaller-buttons pull-left">Tags</button> <ul class="squiggle-tags-list"><li>','</li><li>','</li></ul>');
                }
        ?>
                                                                                </div>
                                                                                <?php } ?>
        </div>
        <?php if (  get_theme_mod('sq_single_even_more_posts', true ) == true ) { ?>
            <?php include_once get_template_directory() . '/template-parts/even-more-post.php' ?>
                <?php } ?>
    </article>
    <!-- #post-<?php the_ID(); ?> -->