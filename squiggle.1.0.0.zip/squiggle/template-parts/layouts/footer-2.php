<div class="footer-element-2">
   <div class="col-md-6 col-sm-6">
    <div class="footer-sidebar">
        <?php dynamic_sidebar( 'sidebar-2');  ?>
    </div>
</div>
<div class="col-md-6 col-sm-6">
    <div class="footer-sidebar">
        <?php dynamic_sidebar( 'sidebar-3');  ?>
    </div>
</div>
<div class="footer-tagline col-md-12">
    <p id="footertext">
        <?php echo get_theme_mod( 'sq_footer_texts' , true); ?>
    </p>
</div>
</div>