<?php 
/**
 * Shuuuu silence is golden
 */

?>
    <div class="full-width-layout">
        <div class="full-width-layout-margined">
            <?php                     
$post_secletor =  get_theme_mod('post_layout_options');
       switch($post_secletor){
        case 1:
          include_once get_template_directory() . '/template-parts/layouts/postlist-1.php';
        break;    
    case 2:
        include_once get_template_directory() . '/template-parts/layouts/postlist-2.php';
        break;
    case 3:
        include_once get_template_directory() . '/template-parts/layouts/footer-3.php';
        break;
    default:
        include_once get_template_directory() . '/template-parts/layouts/postlist-1.php';
} 
                
   ?>
        </div>
    </div>