<div> <button class="Squiggle-button">Latest Posts</button> </div>
   <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div class="main-post-loop">
        <div class="big-thum-section img-is-responsive">
            <?php if ( has_post_thumbnail() ) : ?>
                <?php the_post_thumbnail('full'); ?>
                    <?php endif; ?>
        </div>
        <div class="squiggle-post-meta-section clearfix">
            <h2><a href="<?php echo get_permalink(); ?>"> <?php the_title(); ?> </a></h2>
            <div class="excerpt-post">
                <?php the_excerpt(); ?>
            </div>
        </div>
        <div class="continue-reading-section"> <a href="<?php echo get_permalink(); ?>" class="cont-reading"> <?php echo _e('Continue reading', 'squiggle'); ?> <i class="fa fa-chevron-right"></i></a> </div>
        <div class="squiggly-line"></div>
    </div>
    <?php endwhile; endif; ?>
        <?php
        the_posts_pagination( array(
            'mid_size' => 2,
            'prev_text' => esc_html( '&larr;' ),
            'next_text' => esc_html( '&rarr;' ),
            ) ); 
?>