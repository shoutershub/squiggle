<div> <button class="Squiggle-button">Latest Posts</button> </div>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<div class="main-post-loop-2 clearfix">
    <div class="main-post-loop-2 img-is-responsive">
        <?php if ( has_post_thumbnail() ) : ?>
        <?php the_post_thumbnail('small-block-thumb'); ?>
        <?php else : ?> <img src="<?php echo get_template_directory_uri(); ?>/asset/img/no-medium-thumb.png">
        <?php endif; ?>
        <div class="play-overlay">
            <!-- Video play overlay-->
            <?php
                    $meta_value = get_post_meta( get_the_ID(), 'meta-radio', true );
                    $the_theme_directory = get_template_directory_uri();
                    if( ( $meta_value == 'radio-one' ) ) {
                        ob_start(); ?>
                <div class="sd-post-type"> <img src="<?php echo $the_theme_directory ?>/asset/img/video-thumb.png" class="sd-main-video-ic"> </div>
                <?php echo ob_get_clean(); } ?>
                <!-- Music play overlay-->
                <?php
                    $meta_value = get_post_meta( get_the_ID(), 'meta-radio', true );
                    if( ( $meta_value == 'radio-two' ) ) {
                        ob_start(); ?>
                    <div class="sd-post-type"> <img src="<?php echo $the_theme_directory ?>/asset/img/music-thumb.png" class="sd-main-video-ic"> </div>
                    <?php    echo ob_get_clean();

                    }?>
                    
                    <!-- Gallery play overlay-->
                    <?php
                    $meta_value = get_post_meta( get_the_ID(), 'meta-radio', true );
                    if( ( $meta_value == 'radio-three' ) ) {
                        ob_start(); ?> 
                    <div class="sd-post-type"> <img src="<?php echo $the_theme_directory ?>/asset/img/gallery-thumb.png" class="sd-main-video-ic"> </div>
                        <?php    echo ob_get_clean();

                    }?>
        </div>
    </div>
    <div class="main-post-loop-2-meta">
        <h2>
            <a href="<?php echo get_permalink(); ?>">
                <?php the_title(); ?>
            </a>
        </h2>
        <div class="the-excerpt">
            <?php the_excerpt(); ?>
        </div>
    </div>
</div>
<?php endwhile; ?>
<?php else: ?>
<?php endif; ?>
<?php
        the_posts_pagination( array(
            'mid_size' => 2,
            'prev_text' => esc_html( '&larr;' ),
            'next_text' => esc_html( '&rarr;' ),
            ) ); 
?>
