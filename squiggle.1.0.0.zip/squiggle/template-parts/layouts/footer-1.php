<div class="footer-section-inner">
    <div class="social-footer">
     <?php echo get_theme_mod( 'sq_social_icon');  ?>       
    </div>
    <div class="footer-tagline">
        <p id="footertext">
            <?php echo get_theme_mod( 'sq_footer_texts' , true); ?>
        </p>
    </div>
</div>

