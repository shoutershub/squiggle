<div class="footer-element-3">
    <div class="col-md-4 col-sm-4">
        <div class="footer-sidebar">
            <?php dynamic_sidebar( 'sidebar-2');  ?>
        </div>
    </div>
    <div class="col-md-4 col-sm-4">
        <div class="footer-sidebar">
            <?php dynamic_sidebar( 'sidebar-3');  ?>
        </div>
    </div>
    <div class="col-md-4 col-sm-4">
        <div class="footer-sidebar">
            <?php dynamic_sidebar( 'sidebar-4');  ?>
        </div>
    </div>
    <div class="footer-tagline col-md-12">
        <p id="footertext">
            <?php echo get_theme_mod( 'sq_footer_texts' , true); ?>
        </p>
    </div>
</div>