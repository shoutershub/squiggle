<?php $items = get_theme_mod( 'grid_control_settings', array() );
foreach ($items as $key) {
    switch ($key) {
        case 'Big Grid 1' :
           do_shortcode('[sq_big_grid_function_2]');
            break ;
        case 'Big Grid 2' :
           do_shortcode('[sq_big_grid_function]'); 
            break ;
        case 'Big Grid 3' :
            echo '<code>This Grid Block is Comming soon </code> <br>';
            break ;
     }
 }
?>
    <!-- #End Big Grid -->