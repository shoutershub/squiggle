<div class="breadcrumb">
    <?php get_breadcrumb(); ?>
</div>