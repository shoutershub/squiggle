<div class="related-post-section clearfix col-md-12">
    <div class="the-related-post text-center">
        <h3> <?php _e('Related Posts', 'squiggle')?></h3>
    </div>
    <div class="col-md-12 no-padding">
        <div class="related-post-inner clearfix">
            <?php
                $related = get_posts( array( 'category__in' => wp_get_post_categories($post->ID), 'numberposts' => 3, 'post__not_in' => array($post->ID) ) );
                if( $related ) foreach( $related as $post ) {
                setup_postdata($post); ?>
                <li>
                    <a href="<?php echo get_permalink(); ?>">
                        <div class="related-post-thumbnailnail">
                            <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail('sq-related-thumb'); ?>
                            <?php else : ?> <img src="<?php echo get_template_directory_uri(); ?>/asset/img/no-small-thumb.png">
                            <?php endif; ?>
                            <button class="related-post-cat-overlay"><?php _e('cinematography', 'squiggle')?> </button>
                        </div>
                        <h4>
                            <?php echo wp_trim_words( get_the_title(), 6 ); ?> </h4>
                    </a>
                </li>
                <?php } wp_reset_postdata(); ?>
        </div>
    </div>
</div>
