<?php
// shhhh silence is golden
include_once get_template_directory() . '/template-parts/layouts/single-1.php'; ?>