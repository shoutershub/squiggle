<div class="squiggle-mobile-nav clearfix">
    <div class="col-xs-3 col-sm-4">
        <button class="no-style-btn" data-target="#myNavbar" onclick="openNav()"><i class="fa fa-bars fa-fw fa-2x"></i></button>
    </div>
    <div class="col-xs-9 col-sm-4"> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                 <?php 
                    $id = get_theme_mod('sq_mobile_logo'); if ($id != 0) {
                    $url = wp_get_attachment_url($id); 
                    echo '<img src="' . $url . '" alt="" />';
                    }
                    ?>   
            
                
            </a> </div>
    <div id="show-mobile-search" class="squiggle-mobile-search">
        <form action="#" method="post">
            <div class="squiggle-mobile-search-inner">
                <input class="squiggle-search-box" placeholder="Search anything ...">
                <button class="squiggle-search-btn"> Search </button>
            </div>
        </form>
    </div>
    <div id="squiggle-header-1" class="squiggle-main-mobile-nav">
        <div class="close-nav-btn"> <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> </div>
        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'main-menu',
                            'menu_id'        => 'main-menu',
                        ) );
                    ?>
    </div>
</div>
<div class="header-style-2-outerr">
    <div class="squiggle-wp-nav-inner clearfix">
        <div class="squiggle-wp-logo pull-left">
            <div class="squiggle-wp-logo-inner"> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                                       
                <?php 
                    $id = get_theme_mod('sq_pc_logo'); if ($id != 0) {
                    $url = wp_get_attachment_url($id); 
                    echo '<img src="' . $url . '" alt="" />';
                    } else {
                        echo '<img src="' . get_template_directory_uri() . '/asset/img/logo.png">';
                    }
                    ?>
                    </a> </div>
        </div>
        <div class="squiggle-wp-top-ads pull-right">
            <?php if (  get_theme_mod('sq_nav2_ads_aside_logo') ) { ?>
                <?php echo get_theme_mod('sq_nav2_ads_aside_logo') ?>
                    <?php } else { ?> <img src="<?php echo get_template_directory_uri()  . '/asset/img/ads-728-90px.png' ?>">
                        <?php } ?>
        </div>
    </div>
    <div class="squiggle-wp-main-nav" id="myNavbar">
        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'main-menu',
                            'menu_id'        => 'primary-menu',
                        ) );
                    ?>
    </div>
</div>


<div class="col-md-12 widgets-container">
    <?php dynamic_sidebar( 'sidebar-5');  ?>
</div>