<div class="col-md-12 mobile-menu hidden-lg hidden-md">
    <div class="text-mobile-menu-text text-center"> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
            <?php 
                $id = get_theme_mod('sq_1_mobile_logo'); if ($id != 0) {
                $url = wp_get_attachment_url($id); echo '<img src="' . $url . '" alt="" />';
                }
            ?>    
        </a>
        <?php if(get_theme_mod('sq_hide_blog_info', true ) === true ){  ?>
            <div class="blog-info-section">
                <h2>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                    <?php bloginfo( 'name' ); ?>
                </a>
            </h2>
                <p>
                    <?php bloginfo( 'description'); ?>
                </p>
            </div>
            <?php } ?>
    </div>
    <div class="mobile-menu-inner text-center"> <a href="#" onclick="toggleMobileMenu()"><span class="the-text">Menu</span> <i class="fa fa-bars"></i></a> </div>
    <div class="mobile-menu-inner-element">
        <?php
            wp_nav_menu( array(
                'theme_location' => 'main-menu',
                'menu_id'        => 'main-menu',
                ) );
        ?>
    </div>
</div>
<div class="col-md-12 pc-menu hidden-xs hidden-sm">
    <div class="text-mobile-menu-text text-center"> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
            <?php 
                $id = get_theme_mod('sq_1_pc_logo'); if ($id != 0) {
                $url = wp_get_attachment_url($id); echo '<img src="' . $url . '" alt="" />';
                }
            ?>    
        </a>
        <?php if(get_theme_mod('sq_hide_blog_info', true ) == true ):  ?>
            <div class="blog-info-section">
                <h2>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                    <?php bloginfo( 'name' ); ?> 
                </a>
            </h2>
                <p>
                    <?php bloginfo( 'description' ); ?>
                </p>
            </div>
            <?php endif; ?>
    </div>
    <div class="pc-menu-inner text-center">
        <?php
            wp_nav_menu( array(
                'theme_location' => 'main-menu',
                'menu_id'        => 'main-menu',
                ) );
        ?>
    </div>
</div>
<div class="col-md-12 widgets-container">
    <?php dynamic_sidebar( 'sidebar-5');  ?>
</div>