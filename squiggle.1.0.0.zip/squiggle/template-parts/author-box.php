<div class="athour-section col-md-12 no-padding">
    <div class="text-center">
        <h3>
            <?php _e('About Author', 'squiggle'); ?>
        </h3>
    </div>
    <div class="author-profile-section clearfix">
        <div class="author-box-gratavar">
            <?php echo get_avatar( get_the_author_meta( 'user_email' ), 90 ); ?>
        </div>
        <div class="author-details">
            <h4>
                <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
                    <?php the_author(); ?>
                </a>
            </h4>
            <p><i><a href="<?php the_author_meta('url'); ?>" target="_blank"><?php the_author_meta('url'); ?></a></i></p>
            <div class="authors-description">
                <?php the_author_meta('description'); ?>
            </div>
        </div>
        <div class="author-details-socials">
            <?php  
                //define social variables
                $fb_link = get_the_author_meta('facebook');
                $twitter_link = get_the_author_meta('twitter');
                $googleplus_link = get_the_author_meta('gplus');
                $github_link = get_the_author_meta('github');
                $youtube_link = get_the_author_meta('youtube');
                                   
                    if ($fb_link == !'') { ?>
            <a href="<?php echo $facebook_urlin = get_the_author_meta('facebook'); ?>">
                    <button><i class="fa fa-facebook"></i></button>
                </a>
            <?php } ?>
            <?php if ($twitter_link == !'') { ?>
            <a href="<?php echo $twitter_urlin = get_the_author_meta('twitter'); ?>">
                            <button><i class="fa fa-twitter"></i></button>
                        </a>
            <?php } ?>
            <?php if ($googleplus_link == !'') { ?>
            <a href="<?php echo $gpluslink = get_the_author_meta('gplus'); ?>">
                                    <button><i class="fa fa-google-plus"></i></button>
                                </a>
            <?php } ?>
            <?php if ($github_link == !'') { ?>
            <a href="<?php echo $githublink = get_the_author_meta('github'); ?>">
                                            <button><i class="fa fa-github"></i></button>
                                        </a>
            <?php } ?>
            <?php  if ($github_link == !'') { ?>
            <a href="<?php echo $youtubelink = get_the_author_meta('youtube'); ?>">
                                                    <button><i class="fa fa-youtube"></i></button>
                                                </a>
            <?php } ?>
            <button class="author-total-posts pull-right">
                                                        <?php _e('Total Posts:', 'squiggle'); ?>
                                                            <?php the_author_posts(); ?>
                                                    </button>
        </div>
    </div>
</div>
