<div class="navigation clearfix col-md-12 no-padding">
    <div class="single-navigation-inner clearfix">
        <?php
	the_post_navigation( array(
        'prev_text'	=> __( '<span class="previous-post">&larr; Previous Post</span>', 'squiggle' ) . '<p class="the-previous-article-title">%title</p>',
		'next_text'	=> __( '<span class="next-post">Next Post &rarr; </span>', 'squiggle' ) . '<p class="the-previous-article-title">%title</p>',
	) );
?> </div>
</div>