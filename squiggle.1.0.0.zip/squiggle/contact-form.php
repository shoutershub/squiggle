<?php
/*
Template Name: Contact Form
*/


get_header(); ?>
    <div class="col-md-12 no-padding clearfix">
        <div class="col-md-8 col-sm-8">
            <main id="main" class="site-main">
                <?php
                    while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <header class="entry-header">
                            <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?> </header>
                        <!-- .entry-header -->
                                <div class="entry-content">
                                    <?php
                                        the_content();
                                        wp_link_pages( array(
                                            'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'squiggle' ),
                                            'after'  => '</div>',
                                        ) );
                                     ?> 
                           </div>
                    </article>
                    <?php  endwhile; // End of the loop. ?>
            </main>
            <?php 

//Custom Support Page With Forms
//Payment Notification sent to email
 function html_form_code() {
	echo '<form name="contact-form"  class="contact-form" action="' . esc_url( $_SERVER['REQUEST_URI'] ) . '" method="post">';
	echo '<p>';
	echo _e('Full Name', 'squiggle');
	echo '<input type="text" name="regsiteredusername" value="' . ( isset( $_POST["fullname"] ) ? esc_attr( $_POST["regsiteredusername"] ) : '' ) . '" size="40" />';
	echo '</p>';
    
    echo '<p>';
	echo  _e('Email', 'squiggle');
	echo '<input type="email" name="regsiteredemail" value="' . ( isset( $_POST["emailaddress"] ) ? esc_attr( $_POST["emailaddress"] ) : '' ) . '" size="40" />';
	echo '</p>';

	echo '<p>';
	echo _e('Subject (required)', 'squiggle');
	echo '<input type="text" name="subject" pattern="[a-zA-Z ]+" value="' . ( isset( $_POST["subject"] ) ? esc_attr( $_POST["subject"] ) : '' ) . '" size="40" />';
	echo '</p>';
   
	echo '<p>';
    echo _e('Message', 'squiggle');
	echo '<textarea rows="10" cols="35" name="Paymentdetails">' . ( isset( $_POST["contactmessage"] ) ? esc_attr( $_POST["Paymentdetails"] ) : '' ) . '</textarea>';
	echo '</p>';

	echo '<p><input type="submit" name="cf-submitted" value="Send"></p>';
	echo '</form>';
}

function deliver_mail() {
	// if the submit button is clicked, send the email
	if ( isset( $_POST['cf-submitted'] ) ) {

		// sanitize form values
$fullname = $_POST["fullname"] ;
$emailaddress =  $_POST["emailaddress"] ;
$subject = $_POST["subject"];
$contactmessage = $_POST["contactmessage"];
        
$to = get_option( 'admin_email' );
$subject = "New Message - Via Squiggle contact form";
$headers = "From: $fullname <$emailaddress>" . "\r\n";
$formcontent = "
Full Name: $fullname \n 
Email Address: $emailaddress \n
Reason For Contact: $subject \n
Message: $contactmessage " ;

		// If email has been process for sending, display a success message
		if ( wp_mail( $to, $subject, $formcontent, $headers ) ) {
            
            echo '<div class="form-msg-staus sent">';
			echo _e('Successful! your message was successfully sent , we would get back to you shortly', 'squiggle');
            echo '</div>';
		} else {
            echo '<div class="form-msg-staus">';
			echo _e('Error! sending message, please try again later', 'squiggle');
            echo '</div></br>';
		}
	}
}

function cf_shortcode() {
	ob_start();
	deliver_mail();
	html_form_code();
    
    return ob_get_clean();
    
}

echo cf_shortcode();

?>
            <!-- .entry-content -->
            <?php if ( get_edit_post_link() ) : ?>
            <footer class="entry-footer">
                <?php
				edit_post_link(
					sprintf(
						wp_kses(
							/* translators: %s: Name of current post. Only visible to screen readers */
							__( 'Edit <span class="screen-reader-text">%s</span>', 'squiggle' ),
							array(
								'span' => array(
									'class' => array(),
								),
							)
						),
						get_the_title()
					),
					'<span class="edit-link">',
					'</span>'
				);
			?> </footer>
            <!-- .entry-footer -->
            <?php endif; ?>
        </div>
        <div class="col-md-4 col-sm-4">
            <?php  get_sidebar(); ?>
        </div>
    </div>
    <?php get_footer(); ?>
