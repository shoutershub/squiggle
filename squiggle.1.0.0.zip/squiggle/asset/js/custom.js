jQuery(document).ready(function ($) {
    $('.mobile-menu-inner-element').addClass('toggle-menu');
    $('.toggle-menu ul.sub-menu, .toggle-menu ul.children').addClass('toggle-submenu');
    $('.toggle-menu ul.sub-menu').parent().addClass('toggle-menu-item-parent');
    $('.toggle-menu .toggle-menu-item-parent').append('<span class="toggle-caret"><i class="fa fa-plus"></i></span>');
    $('.toggle-caret').click(function (e) {
        e.preventDefault();
        $(this).parent().toggleClass('active').children('.toggle-submenu').slideToggle('fast');
    });
});
$('.mobile-menu-inner-element').hide();

function toggleMobileMenu() {
    $('.mobile-menu-inner-element').slideToggle('slow');
};
$('#carousel-example-generic').carousel({
    interval: 4000
});
/* nav header style 2*/
function openNav() {
    document.getElementById("squiggle-header-1").style.display = "block";
};

function closeNav() {
    document.getElementById("squiggle-header-1").style.display = "none";
};
jQuery(document).ready(function ($) {
    $('#squiggle-header-1').addClass('toggle-menu');
    $('.toggle-menu ul.sub-menu, .toggle-menu ul.children').addClass('toggle-submenu');
    $('.toggle-menu ul.sub-menu').parent().addClass('toggle-menu-item-parent');
    $('.toggle-menu .toggle-menu-item-parent').append('<span class="toggle-caret"><i class="fa fa-plus"></i></span>');
    $('.toggle-caret').click(function (e) {
        e.preventDefault();
        $(this).parent().toggleClass('active').children('.toggle-submenu').slideToggle('fast');
    });
});

/* Even more post box*/
jQuery(document).ready(function ($) {
    // browser window scroll (in pixels) after which the "back to top" link is shown
    var offset = 300
        , //browser window scroll (in pixels) after which the "back to top" link opacity is reduced
        offset_opacity = 1200
        , //duration of the top scrolling animation (in ms)
        scroll_top_duration = 700
        , //grab the "back to top" link
        $back_to_top = $('.even-more-sq-rt');
    //hide or show the "back to top" link
    $(window).scroll(function () {
        ($(this).scrollTop() > offset) ? $back_to_top.addClass('even-more-post-visible'): $back_to_top.removeClass('even-more-post-visible');
    });
});
jQuery(document).ready(function ($) {
    $('#close-even-more').click(function () {
        $('.even-more-sq-rt').hide();
    });
});