<?php function squiggle_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Right Sidebar', 'squiggle' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'squiggle' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
    
    register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 1', 'squiggle' ),
		'id'            => 'sidebar-2',
		'description'   => esc_html__( 'Add widgets here.', 'squiggle' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
    
    
    
     register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 2 ', 'squiggle' ),
		'id'            => 'sidebar-3',
		'description'   => esc_html__( 'Add widgets here.', 'squiggle' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
    
    
    
      register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 3', 'squiggle' ),
		'id'            => 'sidebar-4',
		'description'   => esc_html__( 'Add widgets here.', 'squiggle' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) ); 
    
    register_sidebar( array(
		'name'          => esc_html__( 'Header Widget (After Nav Menu)', 'squiggle' ),
		'id'            => 'sidebar-5',
		'description'   => esc_html__( 'WIdgets placed here would appear below the Navigation menu.', 'squiggle' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );  
    
    register_sidebar( array(
		'name'          => esc_html__( 'After Post Widget', 'squiggle' ),
		'id'            => 'sidebar-6',
		'description'   => esc_html__( 'WIdgets placed here would appear below the Navigation menu.', 'squiggle' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'squiggle_widgets_init' );
?>