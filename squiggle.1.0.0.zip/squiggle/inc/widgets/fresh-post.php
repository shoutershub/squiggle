<?php
// ------------------------------------------------------
// ------ squiggle Fresh Posts from category ----------------------

class squiggle_fresh_post extends WP_Widget {

	
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'squiggle_fresh_post', 'squiggle',
			'description' => esc_html__('Display a list of latest posts from a specified category.', 'squiggle'),
		);
		parent::__construct( 'squiggle_fresh_post', 'squiggle: Fresh Posts (carousel)', $widget_ops );
	}

   function widget($args, $instance) {  
		extract( $args );
       
		$title = $instance['title'];
		$post_to_show = $instance['post_to_show'];
		$cat_to_show = $instance['cat_to_show'];
       
?>
    <?php echo $before_widget; ?>
        <?php if ( $title ) echo $before_title . esc_attr($title) . $after_title; ?>
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <div class="carousel-inner" role="listbox">
                    <?php
       $posts = new WP_Query(
			"cat=".$cat_to_show."&orderby=date&order=DESC&posts_per_page=".$post_to_show
		); 
	   $count = '';
	   while ( $posts->have_posts()) : $posts->the_post(); $count++; ?>
                        <?php if ($count == 1) : ?>
                            <div class="item active">
                                <a href="<?php echo get_permalink(); ?>">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <?php the_post_thumbnail('carosel-thumb'); ?>
                                            <?php else : ?> <img class="main-post-no-thumb" src="<?php echo get_stylesheet_directory_uri(); ?>/asset/img/no-medium-thumb.png" />
                                                <?php endif; ?>
                                                    <div class="carousel-caption">
                                                        <h4> <?php the_title(); ?>    </h4> </div>
                                </a>
                            </div>
                            <?php elseif ($count >= 2) : ?>
                                <div class="item">
                                    <a href="<?php echo get_permalink(); ?>">
                                        <?php if ( has_post_thumbnail() ) : ?>
                                            <?php the_post_thumbnail('carosel-thumb'); ?>
                                                <?php else : ?> <img class="main-post-no-thumb" src="<?php echo get_stylesheet_directory_uri(); ?>/asset/img/no-medium-thumb.png" />
                                                    <?php endif; ?>
                                                        <div class="carousel-caption">
                                                            <h4> <?php the_title(); ?>  </h4> </div>
                                    </a>
                                </div>
                                <?php else : ?>
                                    <?php endif; ?>
                                        <?php endwhile; ?>
                                            <div class="freshPosts-control">
                                                <a class="carousel-control-left" href="#carousel-example-generic" role="button" data-slide="prev">
                                                    <button class="fa fa-chevron-left" aria-hidden="true"></button> <span class="sr-only">Previous</span> </a>
                                                <a class="carousel-control-right" href="#carousel-example-generic" role="button" data-slide="next">
                                                    <button class="fa fa-chevron-right" aria-hidden="true"></button> <span class="sr-only">Next</span> </a>
                                            </div>
                </div>
            </div>
            <?php echo $after_widget; ?>
                <?php
    }

     function update($new_instance, $old_instance) {				
			$instance = $old_instance;
			$instance['title'] = strip_tags($new_instance['title']);
			$instance['post_to_show'] = strip_tags($new_instance['post_to_show']);
			$instance['cat_to_show'] = strip_tags($new_instance['cat_to_show']);
     return $instance;
    }

 	function form( $instance ) {
        // Set up some default widget settings
  $defaults = array(
    'title' => 'Fresh Posts',
    'post_to_show' => 5 );
    $instance = wp_parse_args( (array) $instance, $defaults );

        
?>
                    <p>
                        <label for="<?php echo $this->get_field_id('title'); ?>">
                            <?php esc_html_e( 'Title:', 'squiggle' ); ?>
                        </label>
                        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php if( isset($instance['title']) ) echo esc_attr($instance['title']); ?>" /> </p>
                    <p>
                        <label for="<?php echo $this->get_field_id('post_to_show'); ?>">
                            <?php esc_html_e( 'How many posts to show (numbers only).', 'squiggle' ); ?>
                        </label>
                        <input class="widefat" id="<?php echo $this->get_field_id('post_to_show'); ?>" name="<?php echo $this->get_field_name('post_to_show'); ?>" type="text" value="<?php if( isset($instance['post_to_show']) ) echo esc_attr($instance['post_to_show']); ?>" /> </p>
                    <p>
                        <label for="<?php echo $this->get_field_id( 'cat_to_show' ); ?>">
                            <?php _e( 'Select a Category:','squiggle' ); ?>
                        </label>
                        <select id="<?php echo $this->get_field_id('cat_to_show'); ?>" name="<?php echo $this->get_field_name('cat_to_show'); ?>" class="widefat" style="width:100%;">
                            <?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { ?>
                                <option <?php selected( $instance[ 'cat_to_show'], $term->term_id ); ?> value="
                                    <?php echo $term->term_id; ?>">
                                        <?php echo $term->name; ?>
                                </option>
                                <?php } ?>
                        </select>
                    </p>
                    <?php  } }

			add_action( 'widgets_init', function(){
	register_widget( 'squiggle_fresh_post' );
});

?>