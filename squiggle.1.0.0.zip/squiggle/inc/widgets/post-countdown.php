<?php
// ------------------------------------------------------
// ------ squiggle Top 10 Post count down ----------------------

class squiggle_top_posts extends WP_Widget {
	
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'squiggle_top_posts', 'squiggle',
			'description' => esc_html__('Display a list of latest posts title in a countdown.', 'squiggle'),
		);
		parent::__construct( 'squiggle_top_posts', 'squiggle: Top Posts', $widget_ops );
	}

   function widget($args, $instance) {  
		extract( $args );
       
		$title = $instance['title'];
		$post_to_show = $instance['post_to_show'];
		$cat_to_show = $instance['cat_to_show'];
       
?>
    <?php echo $before_widget; ?>
        <?php if ( $title ) echo $before_title . esc_attr($title) . $after_title; ?>
            <div class="top-post-count-down-outter">
                <?php
                   $posts = new WP_Query(
                        "cat=".$cat_to_show."&orderby=date&order=DESC&posts_per_page=".$post_to_show
                    );
                        $c = 1; while ( $posts->have_posts()) : $posts->the_post();?>
                    <div class="top-post-count-down clearfix">
                        <div class="top-counter-left pull-left">
                            <?php echo $c++ ?>
                        </div>
                        <h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a> </h2> </div>
                    <?php endwhile; ?>
            </div>
            <?php echo $after_widget; ?>
                <?php
                }
                 function update($new_instance, $old_instance) {				
                        $instance = $old_instance;
                        $instance['title'] = strip_tags($new_instance['title']);
                        $instance['post_to_show'] = strip_tags($new_instance['post_to_show']);
                        $instance['cat_to_show'] = strip_tags($new_instance['cat_to_show']);
                 return $instance;
                }

                function form( $instance ) {
                    // Set up some default widget settings
              $defaults = array(
                'title' => 'Top Posts',
                'post_to_show' => 5 );
                $instance = wp_parse_args( (array) $instance, $defaults );
            ?>
                    <p>
                        <label for="<?php echo $this->get_field_id('title'); ?>">
                            <?php esc_html_e( 'Title:', 'squiggle' ); ?>
                        </label>
                        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php if( isset($instance['title']) ) echo esc_attr($instance['title']); ?>" /> </p>
                    <p>
                        <label for="<?php echo $this->get_field_id('post_to_show'); ?>">
                            <?php esc_html_e( 'How many posts to show (numbers only).', 'squiggle' ); ?>
                        </label>
                        <input class="widefat" id="<?php echo $this->get_field_id('post_to_show'); ?>" name="<?php echo $this->get_field_name('post_to_show'); ?>" type="text" value="<?php if( isset($instance['post_to_show']) ) echo esc_attr($instance['post_to_show']); ?>" /> </p>
                    <p>
                        <label for="<?php echo $this->get_field_id( 'cat_to_show' ); ?>">
                            <?php _e( 'Select a Category:','squiggle' ); ?>
                        </label>
                        
                        <select id="<?php echo $this->get_field_id('cat_to_show'); ?>" name="<?php echo $this->get_field_name('cat_to_show'); ?>" class="widefat" style="width:100%;">
            <?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { ?>
            <option <?php selected( $instance['cat_to_show'], $term->term_id ); ?> value="<?php echo $term->term_id; ?>"><?php echo $term->name; ?></option>
            <?php } ?>      
        </select>
                
                    </p>
                    <?php  } }

			add_action( 'widgets_init', function(){
	register_widget( 'squiggle_top_posts' );
});


?>