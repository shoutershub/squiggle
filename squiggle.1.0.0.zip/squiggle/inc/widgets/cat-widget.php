<?php
// ------------------------------------------------------
// ------ squiggle Categories with count ----------------------

class squiggle_categories extends WP_Widget {
	
	
		public function __construct() {
		$widget_ops = array( 
			'classname' => 'squiggle_categories', 'squiggle',
			'description' => esc_html__('Display Categories with Posts Counts.', 'squiggle'),
		);
		parent::__construct( 'squiggle_categories', 'squiggle: Categories', $widget_ops );
	}

   function widget($args, $instance) {  
		extract( $args );
		$title_tw = $instance['title_tw'];
		$exclude = $instance['exclude'];
?>
    <?php echo $before_widget; ?>
        <?php if ( $title_tw ) echo $before_title . esc_attr($title_tw) . $after_title; ?>
            <?php
    
    $categories = get_categories(array('type' => 'post', 'orderby' => 'name', 'exclude'  =>  $exclude , 'order' => 'ASC', 'show_count' => 1));
        
    foreach ($categories as $category) {
                    if (strtolower($category->cat_name) != 'uncategorized') {
                            $buffy = '<div class="the-cat-list clearfix"><a href="' . get_category_link($category->cat_ID) . '"><div class="pull-left">' . $category->name . '</div><div class="pull-right">' . $category->count . '</div></a></div>';
        echo $buffy;
                    }
    }

?>
                <?php echo $after_widget; ?>
                    <?php
    }

     function update($new_instance, $old_instance) {				
			$instance = $old_instance;
			$instance['title_tw'] = strip_tags($new_instance['title_tw']);
			$instance['exclude'] = strip_tags($new_instance['exclude']);
     return $instance;
    }

 	function form( $instance ) {
        // Set up some default widget settings
  $defaults = array(
    'title_tw' => 'Top Categories');
    $instance = wp_parse_args( (array) $instance, $defaults );

        
?>
                        <p>
                            <label for="<?php echo $this->get_field_id('title_tw'); ?>">
                                <?php esc_html_e( 'Title:', 'squiggle' ); ?>
                            </label>
                            <input class="widefat" id="<?php echo $this->get_field_id('title_tw'); ?>" name="<?php echo $this->get_field_name('title_tw'); ?>" type="text" value="<?php if( isset($instance['title_tw']) ) echo esc_attr($instance['title_tw']); ?>" /> </p>
                        <p>
                            <label for="<?php echo $this->get_field_id('exclude'); ?>">
                                <?php esc_html_e( 'Exclude Category: only Category ID are accepted in this field, seperate ID by commas (,)', 'squiggle' ); ?>
                            </label>
                            <input class="widefat" id="<?php echo $this->get_field_id('exclude'); ?>" name="<?php echo $this->get_field_name('exclude'); ?>" type="text" value="<?php if( isset($instance['exclude']) ) echo esc_attr($instance['exclude']); ?>" /> </p>
                        <?php  } }
			add_action( 'widgets_init', function(){
	register_widget( 'squiggle_categories' );
});

?>