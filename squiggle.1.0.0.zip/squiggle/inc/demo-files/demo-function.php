<?php
function ocdi_import_files() {
  return array(
    array(
      'import_file_name'             => 'Dark Version',
      'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo-files/dark-version/xml-export-file-dark-v1.xml',
      'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-files/dark-version/widgets-export.json',
      'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo-files/dark-version/customizer-export-dark-v1.dat',

      'import_preview_image_url'   =>   'https://foreigncodes.com/wp-content/uploads/2018/01/dark-v-1.png',
      'import_notice'                => __( 'After you import this demo, you can change any predefined settings such as background image, Nav type etc. manually in the theme customizer option. Note: post content would also be imported.', 'squiggle' ),
      'preview_url'                  => '#',
    ),
    array(
      'import_file_name'             => 'light version ',
      'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo-files/light-version/xml-export-file-v1.xml',
      'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-files/light-version/widgets-export.json',
      'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo-files/light-version/customizer-export-v1.dat',
      'import_preview_image_url'     => 'https://foreigncodes.com/wp-content/uploads/2018/01/light-v-1.png',
      'import_notice'                => __( 'After you import this demo, you can change any predefined settings you want manually. Note: post content would also be imported.', 'squiggle' ),
      'preview_url'                  => '#',
    ),
    
    array(
      'import_file_name'             => 'RTL (right to left)',
      'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo-files/right-to-left/rtl-xml-export-file.xml',
      'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-files/right-to-left/widgets-export.json',
      'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo-files/right-to-left/customizer-export-rtl.dat',
      'import_preview_image_url'     => 'https://foreigncodes.com/wp-content/uploads/2018/01/right-to-left.png',
      'import_notice'                => __( 'After you import this demo, you can change any predefined settings you want manually , post content would also be imported.', 'squiggle' ),
      'preview_url'                  => '#',
    ),
  );
}
add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );
add_filter( 'pt-ocdi/regenerate_thumbnails_in_content_import', '__return_false' );
add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );



?>