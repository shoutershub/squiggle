<?php 

require get_template_directory() . '/inc/wp-customize-image-reloaded.php';

function wpt_register_theme_customizer( $wp_customize ) {

	// Customize title and tagline sections and labels
	$wp_customize->get_section('title_tagline')->title = __('Site Name and Description', 'squiggle');  
	$wp_customize->get_control('blogname')->label = __('Site Name', 'squiggle');  
	$wp_customize->get_control('blogdescription')->label = __('Site Description', 'squiggle');  
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

	// Customize the Front Page Settings
	$wp_customize->get_section('static_front_page')->title = __('Homepage Preferences', 'squiggle');
	$wp_customize->get_section('static_front_page')->priority = 20;
	$wp_customize->get_control('show_on_front')->label = __('Choose Homepage Preference', 'squiggle');  
	$wp_customize->get_control('page_on_front')->label = __('Select Homepage', 'squiggle');  
	$wp_customize->get_control('page_for_posts')->label = __('Select Blog Homepage', 'squiggle');  

	// Customize Background Settings
	$wp_customize->get_section('background_image')->title = __('Background Styles', 'squiggle');  
	$wp_customize->get_control('background_color')->section = 'background_image'; 


	$wp_customize->get_control('display_header_text')->section = 'custom_logo';  
    
    //remove unwanted wordpress customizer follow-come settings
    
    $wp_customize->remove_control("display_header_text");
    $wp_customize->remove_section("header_image");
    $wp_customize->remove_control("header_text_styles");
    $wp_customize->remove_section("header_text_styles");
    $wp_customize->remove_setting("header_textcolor");
    $wp_customize->remove_control("header_textcolor");
    
    // Add Custom Navigation settings and controls

    $wp_customize->add_section( 'sq_nav_design_select' , array(
        'title'      => __('Select Navigation','squiggle'), 
        'panel'      => 'design_settings',
        'priority'   => 10,
      ) );   // Navigation Section Create 
    
    
    $wp_customize->add_setting('nav_type_select', array(
        'default'     => '1',
        'sanitize_callback' => 'sanitize_text',
    ));
    
    $wp_customize->add_control(new Nav_Select_Custom_Control($wp_customize, 'nav_type_select', array(
        'label'     	=> esc_attr__( 'Navigation type', 'squiggle' ),
        'description'   => esc_attr__( 'Choose a Navigation type for your blog', 'squiggle' ),
        'settings'  	=> 'nav_type_select',
        'section'   	=> 'sq_nav_design_select',
    )));
    
    $wp_customize->add_section( 'sq_nav_design' , array(
        'title'      => __('Navigation Design 1','squiggle'), 
        'panel'      => 'design_settings',
        'priority'   => 30    
      ) );  // Navigation Design Section Create 
    
    $wp_customize->add_setting(
          'sq_1_pc_logo', array(
              'default'         => get_template_directory_uri() . '/asset/img/logo.png ',
			  'sanitize_callback' => 'sanitize_text',
          )
      );

    $wp_customize->add_control(
           new WP_Customize_Cropped_Image_Control( $wp_customize, 'sq_1_pc_logo_ctr', array(
              'label'      => __( 'Change PC logo', 'squiggle' ),
              'description'      => __( 'Use this option to chanage PC Logo', 'squiggle' ),
              'section'    => 'sq_nav_design',
              'settings'   => 'sq_1_pc_logo',
              'context'    => 'sq_custom_Pc_logo', 
              'width'      => '230',
              'height'      => '140',
              'sanitize_callback' => 'absint'

            )
         )
    ); 

    // logo Settings and controls
    
    $wp_customize->add_setting(
         'sq_1_mobile_logo', array(
            'default'         => get_template_directory_uri() . '/asset/img/logo.PNG ',
			'sanitize_callback' => 'sanitize_text',
       )
    );

    $wp_customize->add_control(
       new WP_Customize_Cropped_Image_Control(
           $wp_customize,
           'sq_1_mobile_logo_ctr', array(
               'label'      => __( 'Change Mobile logo', 'squiggle' ),
               'description'      => __( 'Use this option to Mobile PC Logo', 'squiggle' ),
               'section'    => 'sq_nav_design',
               'settings'   => 'sq_1_mobile_logo',
               'context'    => 'sq_custom_mobile_logo', 
               'width'      => '230',
               'height'      => '140',
               'sanitize_callback' => 'absint'
               
           )
       )
    ); 
    
    // blog info section and control
     $wp_customize->add_setting(
        'sq_hide_blog_info', array(
        'default'         => true,
        'sanitize_callback' => 'sanitize_textarea',
          )
    );

  // navigation background control and settings
    $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control( $wp_customize, 'sq_hide_blog_info_ctr', array(
            'description'    =>    __( 'Display Site name / Description', 'squiggle' ),
            'label'    =>    __( 'Check here', 'squiggle'),
            'section'  => 'sq_nav_design',
            'settings' => 'sq_hide_blog_info',
            'type'     => 'checkbox'
        )
      )
    );  
    

    // Blog background settings and control
     $wp_customize->add_setting(
          'sq_nav_design_settings_background',
          array(
              'default'           => __( '#fff', 'squiggle' ),
			  'sanitize_callback' => 'sanitize_text',

          )
      );

     $wp_customize->add_control(
           new WP_Customize_Color_Control(
               $wp_customize,
               'sq_nav_design_settings_background_ctr',
                array(
                    'label'          => __( 'Change Navigation Background Color', 'squiggle' ),
                    'section'        => 'sq_nav_design',
                    'settings'       => 'sq_nav_design_settings_background',
                )
            )
    );
    
    // Nav links colors and controls

         $wp_customize->add_setting(
          'sq_nav_design_settings_sitename_color',
          array(
              'default'           => __( '#444', 'squiggle' ),
			  'sanitize_callback' => 'sanitize_text',

          )
      );
    
    // Site Description color control and settings

     $wp_customize->add_control(
           new WP_Customize_Color_Control(
               $wp_customize,
               'sq_nav_design_settings_sitename_color_ctr',
                array(
                    'label'          => __( 'Change Description Color', 'squiggle' ),
                    'section'        => 'sq_nav_design',
                    'settings'       => 'sq_nav_design_settings_sitename_color',
                )
            )
       ); 


     $wp_customize->add_setting(
          'sq_nav_design_settings_description_color',
          array(
              'default'           => __( '#444', 'squiggle' ),
			  'sanitize_callback' => 'sanitize_text',

          )
      );


    // Site Name color control and settings

     $wp_customize->add_control(
           new WP_Customize_Color_Control(
               $wp_customize,
               'sq_nav_design_settings_description_color_ctr', array(
                    'label'          => __( 'Change Sitename Color', 'squiggle' ),
                    'section'        => 'sq_nav_design', 
                    'settings'       => 'sq_nav_design_settings_description_color',
                )
            )
       ); 

       $wp_customize->add_setting(
          'sq_nav_design_settings_dropdown_background', array(
              'default'           => __( '#ebebeb', 'squiggle' ),
			  'sanitize_callback' => 'sanitize_text',

          )
      );
    
    // Sub menu background color

     $wp_customize->add_control(
           new WP_Customize_Color_Control(
               $wp_customize,
               'sq_nav_design_settings_dropdown_background_ctr', array(
                    'label'          => __( 'Change Sub-menu Background Color', 'squiggle' ),
                    'section'        => 'sq_nav_design',
                    'settings'       => 'sq_nav_design_settings_dropdown_background',
                )
            )
       );   
    
       $wp_customize->add_setting(
          'sq_nav_design_settings',
          array(
              'default'           => __( '#333333', 'squiggle'), 
			  'sanitize_callback' => 'sanitize_text',
          )
      );

    // change navigation color link

     $wp_customize->add_control(
           new WP_Customize_Color_Control(
               $wp_customize,
               'sq_nav_custom_color', array(
                    'label'          => __( 'Change Navigation link Color', 'squiggle' ),
                    'section'        => 'sq_nav_design',
                    'settings'       => 'sq_nav_design_settings',
                )
            )
    );   
     
   $wp_customize->add_setting(
      'sq_nav_design_settings_hover',  array(
          'default'           => __( '#777777', 'squiggle' ), 
		  'sanitize_callback' => 'sanitize_text',
      )
    );
    
    // navigation color on hover

    $wp_customize->add_control(
           new WP_Customize_Color_Control(
               $wp_customize,
               'sq_nav_custom_color_hover_ctr', array(
                    'label'          => __( 'Change Navigation link Color (on hover)', 'squiggle' ),
                    'section'        => 'sq_nav_design',
                    'settings'       => 'sq_nav_design_settings_hover',
            )
        )
    );   

     $wp_customize->add_setting(
          'sq_nav_design_settings_boder', array(
              'default'           => __( '#777777', 'squiggle' ),  
			  'sanitize_callback' => 'sanitize_text',
          )
      );

    //nav border color
    
     $wp_customize->add_control(
           new WP_Customize_Color_Control(
               $wp_customize,
               'sq_nav_custom_color_border_ctr',
                array(
                    'label'          => __( 'Change Navigation border Color', 'squiggle' ),
                    'section'        => 'sq_nav_design',
                    'settings'       => 'sq_nav_design_settings_boder',
                )
            )
       );   


      $wp_customize->add_setting(
                'sq_nav_design_settings_boder_style', array(
                    'default'           => __( 'solid', 'squiggle' ),  
					'sanitize_callback' => 'sanitize_text',
          )
      );

    // nav border weight
    $wp_customize->add_control( new WP_Customize_Control(
     $wp_customize,
     'sq_nav_custom_color_border_weight_style_ctr', array(
        'label'      => __( 'Select Boder Style (Defualt style is solid)', 'squiggle' ), 
        'settings'   => 'sq_nav_design_settings_boder_style',
        'section'    => 'sq_nav_design',
        'type'    => 'select',
        'choices' => array(
            'solid' => 'solid',
            'dashed' => 'dashed',
            'dotted' => 'dotted',
            'double' => 'double',
            'groove' => 'groove',
          )
        ) 
     ));
    
    
        
    $wp_customize->add_setting(
          'sq_nav_design_bg_trans', array(
              'default'         => false,
			  'sanitize_callback' => 'sanitize_text',
          )
      );


    // navigation background control and settings
    $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control( $wp_customize, 'sq_nav_design_bg_trans_ctr', array(
            'description'    =>    __( 'Make Navigation Background transparent (if background image is set)', 'squiggle' ),
            'label'    =>    __( 'Check here','squiggle'),
            'section'  => 'sq_nav_design',
            'settings' => 'sq_nav_design_bg_trans',
            'type'     => 'checkbox'
        )
      )
    );  
    
    $wp_customize->add_setting(
        'sq_nav_design_show_border', array(
              'default'         => false,
			  'sanitize_callback' => 'sanitize_text',
         )
    );

    $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control( $wp_customize, 'sq_nav_design_show_border_ctr', array(
            'description'    =>    __( 'Remove top and bottom navigation border lines', 'squiggle' ),
            'label'    =>    __( 'Check here', 'squiggle' ),
            'section'  => 'sq_nav_design',
            'settings' => 'sq_nav_design_show_border',
            'type'     => 'checkbox'
        )
      )
    );  
    
    
    // Starting navigation style 2 section, controls and settings
    $wp_customize->add_section( 'sq_nav_design_2' , array(
        'title'      => __('Navigation Design 2','squiggle'), 
        'panel'      => 'design_settings',
        'priority'   => 40    
      ) ); 


    $wp_customize->add_setting(
          'sq_pc_logo', array(
              'default'         => get_template_directory_uri() . '/asset/img/logo.PNG ',
			  'sanitize_callback' => 'sanitize_text',
          )
      );

    $wp_customize->add_control(
      new WP_Customize_Cropped_Image_Control( $wp_customize, 'pc_custom_logo', array(
         'label'      => __( 'Change Mobile Logo', 'squiggle' ),
         'description'      => __( 'Use this option to chnage PC Logo', 'squiggle' ),
         'section'    => 'sq_nav_design_2',
         'settings'   => 'sq_pc_logo',
         'context'    => 'sq_custom_Pc_logo', 
         'width'      => '230',
         'height'      => '110',
         'sanitize_callback' => 'absint'
        )
    )); 

    $wp_customize->add_setting(
         'sq_mobile_logo',  array(
              'default'         => get_template_directory_uri() . '/asset/img/mobile-logo.png ',
			  'sanitize_callback' => 'sanitize_text',
          )
      );

    $wp_customize->add_control(
        new WP_Customize_Cropped_Image_Control( $wp_customize, 'mobile_custom_logo', array(
         'label'      => __( 'Change Mobile Logo', 'squiggle' ),
         'description'      => __( 'Use this option to change Mobile Logo', 'squiggle' ),
         'section'    => 'sq_nav_design_2',
         'settings'   => 'sq_mobile_logo',
         'context'    => 'sq_custom_mobile_logo', 
         'width'      => '113',
         'height'      => '34',
         'sanitize_callback' => 'absint'

        ))
     ); 
    
     $wp_customize->add_setting( 'sq_nav_2_design_settings_background', array(
              'default'           => __( '#333', 'squiggle' ),
		 	  'sanitize_callback' => 'sanitize_text',
          )
      );

     $wp_customize->add_control(
           new WP_Customize_Color_Control( $wp_customize, 'sq_nav_design_settings_background_ctr', array(
            'label'          => __( 'Change Navigation Background Color', 'squiggle' ),
            'section'        => 'sq_nav_design_2',
            'settings'       => 'sq_nav_2_design_settings_background',
        ))
       );    

     $wp_customize->add_setting( 'sq_nav_2_design_settings_color', array(
            'default'           => __( '#fff', 'squiggle' ),
			'sanitize_callback' => 'sanitize_text',
    ));
    
     $wp_customize->add_control(
           new WP_Customize_Color_Control( $wp_customize, 'sq_nav_design_settings_color_ctr', array(
            'label'          => __( 'Change Navigation Link Color', 'squiggle' ),
            'section'        => 'sq_nav_design_2',
            'settings'       => 'sq_nav_2_design_settings_color',
        ))
       );

    
    $wp_customize->add_setting( 'sq_nav_2_design_settings_color_hover', array(
            'default'           => __( '#fff', 'squiggle' ), 
			'sanitize_callback' => 'sanitize_text',
    ));

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize, 'sq_nav_design_settings_color_hover_ctr', array(
             'label'          => __( 'Change Navigation Link Color (on Hover)', 'squiggle' ),
             'section'        => 'sq_nav_design_2',
             'settings'       => 'sq_nav_2_design_settings_color_hover',
          )
         )
       );
    
    
    $wp_customize->add_setting( 'sq_nav_2_design_settings_color_submenu', array(
              'default'           => __( '#333', 'squiggle' ),
			  'sanitize_callback' => 'sanitize_text',
    ));
    
    $wp_customize->add_control(
           new WP_Customize_Color_Control(
               $wp_customize,
               'sq_nav_design_settings_color_submenu_ctr',
                array(
                    'label'          => __( 'Change Sub-menu Background Color', 'squiggle' ),
                    'section'        => 'sq_nav_design_2',
                    'settings'       => 'sq_nav_2_design_settings_color_submenu',
                )
            )
       );


          $wp_customize->add_setting(
          'sq_nav2_ads_aside_logo',
          array(
              'default'           =>  '<img src="' . get_template_directory_uri() . '/asset/img/ads-728-90px.png">',
			  'sanitize_callback' => 'sanitize_text',
          )
      );


        $wp_customize->add_control(
            new WP_Customize_Control(
                $wp_customize,
                'sq_nav2_ads_aside_logo_ctr',
                array(
                    'label'          => __( 'Ads Beside logo', 'squiggle' ),
                    'section'        => 'sq_nav_design_2',
                    'settings'       => 'sq_nav2_ads_aside_logo',
                    'type'           => 'textarea'
                )
            )
       );   
    

    
 
    /* End Nav style 2*/
    
 

  // Add Custom CSS Textfield
  $wp_customize->add_section( 'custom_css_field' , array(
    'title'      => __('Custom CSS','squiggle'), 
    'panel'      => 'design_settings',
    'priority'   => 2000    
  ) );  
  $wp_customize->add_setting(
      'wpt_custom_css',
      array(          
          'sanitize_callback' => 'sanitize_textarea'          
      )
  );
  $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'custom_css',
            array(
                'label'          => __( 'Add custom CSS here', 'squiggle' ),
                'section'        => 'custom_css_field',
                'settings'       => 'wpt_custom_css',
                'type'           => 'textarea'
            )
        )
   );

    
    
    $wp_customize->add_section( 'custom_js_field' , array(
    'title'      => __('Custom Javascript','squiggle'), 
    'panel'      => 'design_settings',  
    'priority'   => 3000  
  ) );  
  $wp_customize->add_setting(
      'sq_custom_js',
      array(          
          'sanitize_callback' => 'sanitize_textarea',
          'default'         => '// enter javascript here '
      )
  );
  $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'custom_javascript',
            array(
                'label'          => __( 'Add custom Javascript here', 'squiggle' ),
                'description' => __( 'Add Header codes (ex: Google webmaster verification code, Buysellads Script, Bing Webmaster Center, Alexa Verification Code.)', 'squiggle' ),
                'section'        => 'custom_js_field',
                'settings'       => 'sq_custom_js',
                'type'           => 'textarea'
            )
        )
   );
    
/** Select layout **/
    
    $wp_customize->add_section( 'image-ctr-options' , array(
    'title'      => __('Layout Desgin','squiggle'),  
    'priority'   => 20  
  ) );  
    
$wp_customize->add_setting('image_options', array(
	'default'     => '1',
	'sanitize_callback' => 'sanitize_text',
));
$wp_customize->add_control(new Image_Select_Custom_Control($wp_customize, 'image_options', array(
	'label'     	=> esc_attr__( 'Layout', 'squiggle' ),
	'description'   => esc_attr__( 'Choose the layout for your blog', 'squiggle' ),
	'settings'  	=> 'image_options',
	'section'   	=> 'image-ctr-options',
)));
    
$wp_customize->add_setting('post_layout_options', array(
	'default'     => '1',
	'sanitize_callback' => 'sanitize_text',
));
$wp_customize->add_control(new post_Select_Custom_Control($wp_customize, 'post_layout_options', array(
	'label'     	=> esc_attr__( 'Layout', 'squiggle' ),
	'description'   => esc_attr__( 'Choose the layout for your blog', 'squiggle' ),
	'settings'  	=> 'post_layout_options',
	'section'   	=> 'image-ctr-options',
)));
    
    

$wp_customize->add_section( 'font_and_typography' , array(
    'title'      => __('Fonts & Typography','squiggle'),  
    'priority'   => 30  
  ) ); 
    
    $wp_customize->add_section( 'homepage_design' , array(
    'title'      => __('Homepage design','squiggle'),  
    'priority'   => 30  
  ) );  
    

    

// Check that the class exists before trying to use it
    if (class_exists('Kirki')) {

       Kirki::add_field( '', array(
        'type'        => 'sortable',
        'settings'    => 'grid_control_settings',
        'label'       => __( 'Template parts for single posts', 'squiggle' ),
        'description' => __( 'You can enable/disable the template parts that interest you below and reorder them to your liking.', 'squiggle' ),
        'section'     => 'homepage_design',
        'default'     => array(
            'Big Grid 1',
        ),
        'choices'     => array(
            'Big Grid 1'          => __( 'Big Grid 1', 'squiggle' ),
            'Big Grid 2'           => __( 'Big Grid 2', 'squiggle' ),
            'Big Grid 3' => __( 'Big Grid 3 (comming soon)', 'squiggle' ),
        ),
        'priority'    => 10,
    ) );

    }


/* Fonts and Family*/
include_once get_template_directory() . '/inc/customizer/fonts.php';
    
    $wp_customize->add_setting( 
     'sq_general_p_font', array(
     'default' => 'Open Sans', 
	 'transport' => 'refresh',
	 'sanitize_callback' => 'sanitize_text',
    )
    );
		
    $wp_customize->add_control( 'control_text_logo_font', array( 
     'label' => 'Select a Font for p tag site wide',
     'section' => 'font_and_typography',
     'settings' => 'sq_general_p_font',
     'type' => 'select',
     'choices' => $all_fonts ) );
		

    $wp_customize->add_setting( 'sq_general_h_font', array( 
     'default' => 'Coustard',
	 'transport' => 'refresh',
	 'sanitize_callback' => 'sanitize_text',
    ) 
    );
		
    $wp_customize->add_control( 'control_heading_font', array(	
     'label' => 'Select Heading Font (sitewide)',
     'section' => 'font_and_typography',
     'settings' => 'sq_general_h_font',
     'type' => 'select',
     'choices' => $all_fonts 
    ) 
    );    
    
    $wp_customize->add_setting(
      'sq_h1_color',
      array(
          'default'         => '#333',
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  $wp_customize->add_control(
       new WP_Customize_Color_Control(
           $wp_customize,
           'custom_h1_color',
           array(
               'label'      => __( 'Heading Color ( Sitewide )', 'squiggle' ),
               'section'    => 'font_and_typography',
               'settings'   => 'sq_h1_color' 
            )
       )
   ); 
  $wp_customize->add_setting(
      'sq_h1_font_size',
      array(
          'default'         => '28px',
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'custom_h1_font_size',
            array(
                'label'          => __( 'H1 Font Size (H1 only)', 'squiggle' ),
                'section'        => 'font_and_typography',
                'settings'       => 'sq_h1_font_size',
                'type'           => 'select',
                'choices'        => array(
                  '22px'   => '22px',
                  '28px'   => '28px  (defualt)',
                  '35px'   => '35px ',
                  '32px'   => '32px',
                  '42px'   => '42px'
                )
            )
        )       
   );   
 
  $wp_customize->add_setting(
      'sq_p_color',
      array(
          'default'         => '#444',
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  $wp_customize->add_control(
       new WP_Customize_Color_Control(
           $wp_customize,
           'custom_p_color_ctr',
           array(
               'label'      => __( 'Paragraph Color ( Sitewide )', 'squiggle' ),
               'section'    => 'font_and_typography',
               'settings'   => 'sq_p_color' 
           )
       )
   ); 
  $wp_customize->add_setting(
      'sq_p_font_size',
      array(
          'default'         => '14px',
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'custom_p_font_size_ctr',
            array(
                'label'          => __( 'Paragraph Font Size (p tags only)', 'squiggle' ),
                'section'        => 'font_and_typography',
                'settings'       => 'sq_p_font_size',
                'type'           => 'select',
                'choices'        => array(
                  '12px'   => '12px',
                  '14px'   => '14px (defualt)',
                  '16px'   => '16px',
                  '18px'   => '18px',
                  '20px'   => '20px'
                )
            )
        )       
   );   
 
    $wp_customize->add_section( 'sq_single_post' , array(
    'title'      => __('Single Post setting','squiggle'),  
    'priority'   => 40  
  ) );
    
 
        $wp_customize->add_setting(
      'sq_allow_inlinepost_ads',
      array(
          'default'         => '<img src="'. get_template_directory_uri() . '/asset/img/blog-ad-300x250.jpg">',
		  'sanitize_callback' => 'sanitize_text',
        )
  );     
            
    
  $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'sq_allow_inlinepost_ads_ctr',
            array(
                'label'          => __( 'In Post Ads', 'squiggle' ),
                'section'        => 'sq_single_post',
                'settings'       => 'sq_allow_inlinepost_ads',
                'type'           => 'textarea',
            )
        )       
   );   
 

     $wp_customize->add_setting(
      'sq_allow_inlinepost_ads_count',
      array(
          'default'         => '0',
		  'sanitize_callback' => 'sanitize_text',
		  
		  
      )
  );
  $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'sq_allow_inlinepost_ads_count_ctr',
            array(
                'label'          => __( 'After X amount of paragraph', 'squiggle' ),
                'section'        => 'sq_single_post',
                'settings'       => 'sq_allow_inlinepost_ads_count',
                'type'           => 'select',
                'choices'        => array(
                  '0'   => '0 (defualt)',
                  '1'   => '1',
                  '2'   => '2',
                  '3'   => '3',
                  '4'   => '4',
                  '5'   => '5',
                )
            )
        )       
   );   
    
    
    
     $wp_customize->add_setting(
      'sq_allow_inlinepost_ads_position',
      array(
          'default'         => '1',
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'sq_allow_inlinepost_ads_position_ctr',
            array(
                'label'          => __( 'Ads position', 'squiggle' ),
                'section'        => 'sq_single_post',
                'settings'       => 'sq_allow_inlinepost_ads_position',
                'type'           => 'select',
                'choices'        => array(
                  '1'   => 'left',
                  '2'   => 'right',
                )
            )
        )       
   );  
    
        
    $wp_customize->add_setting(
      'sq_single_shw_post_rdate',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_rdate_ctr',
            array(
                'description'    =>    __( 'Show or Hide Post Date', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_rdate',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
    
    
    
    $wp_customize->add_setting(
      'sq_single_shw_post_author',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_author_ctr',
            array(
                'description'    =>    __( 'Show or Hide Post Author name', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_author',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
    
    
    $wp_customize->add_setting(
      'sq_single_shw_post_cate',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_cate_ctr',
            array(
                'description'    =>    __( 'Show or Hide Post Category', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_cate',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
    
        $wp_customize->add_setting(
      'sq_single_shw_post_comments_count',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_comments_count_ctr',
            array(
                'description'    =>    __( 'Show or Hide Post Comment count', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_comments_count',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
    
           $wp_customize->add_setting(
      'sq_single_shw_post_share_btn',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_share_btn_ctr',
            array(
                'description'    =>    __( 'Show or Hide Post Share buttons', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_share_btn',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
    
       $wp_customize->add_setting(
      'sq_single_shw_post_post_navi',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_post_navi_ctr',
            array(
                'description'    =>    __( 'Show or Hide Post Navigation', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_post_navi',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
    
    
     $wp_customize->add_setting(
      'sq_single_shw_post_related_post',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_related_post_ctr',
            array(
                'description'    =>    __( 'Show or Hide Related Posts', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_related_post',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
    
    
      $wp_customize->add_setting(
      'sq_single_shw_post_post_author_box',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_post_author_box_ctr',
            array(
                'description'    =>    __( 'Show or Hide Author box', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_post_author_box',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
    
    $wp_customize->add_setting(
      'sq_single_shw_post_post_tag',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_shw_post_post_tag_ctr',
            array(
                'description'    =>    __( 'Show or Hide Tags beneath post', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_shw_post_post_tag',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    

    $wp_customize->add_setting(
      'sq_single_even_more_posts',
      array(
          'default'         => true,
		  'sanitize_callback' => 'sanitize_text',
      )
  );
  
     $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_single_even_more_posts_ctr',
            array(
                'description'    =>    __( 'Show or Hide Even more Post (slide nav)', 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle' ),
                'settings' => 'sq_single_even_more_posts',
                'type'     => 'checkbox',
                'section'  => 'sq_single_post'
            )
        )
   );
    
       
// Add Custom Footer Text
  $wp_customize->add_section( 'custom_footer_text' , array(
    'title'      => __('Footer','squiggle'),
    'priority'   => 50    
  ) );  
    
    
   $wp_customize->add_setting(
      'sq_social_icon',
      array(
          'default'           => __( '
            <div class="social-footer">
            <li> <a href="http://facebook.com"><button><i class="fa fa-facebook"></i></button></a></li>
            <li> <a href="http://twitter.com"><button><i class="fa fa-twitter"></i></button></a></li>
            <li> <a href="http://plus.google.com"><button><i class="fa fa-google-plus"></i></button></a></li>
            <li> <a href="http://youtube.com"><button><i class="fa fa-youtube-play"></i></button></a></li>
            <li> <a href="http://instagram.com/"><button><i class="fa fa-instagram"></i></button></a></li>
            </div>', 'squiggle' 
            ),
          //'transport'         => 'postMessage',
          'sanitize_callback' => 'sanitize_textarea'          
      )
  );
    
 $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'custom_footer_icons',
            array(
                'label'          => __( 'Footer Text', 'squiggle' ),
                'section'        => 'custom_footer_text',
                'settings'       => 'sq_social_icon',
                'type'           => 'textarea'
            )
        )
   );   
    
    
  $wp_customize->add_setting(
      'sq_footer_texts',
      array(
          'default'           => __( '<button class="Squiggle-button">Squiggle</button> Powered by WordPress . Built by Foreigncodes', 'squiggle' ),
          //'transport'         => 'postMessage',
          'sanitize_callback' => 'sanitize_text'          
      )
  );
    
  $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize,
            'custom_footer_text',
            array(
                'label'          => __( 'Footer Text', 'squiggle' ),
                'section'        => 'custom_footer_text',
                'settings'       => 'sq_footer_texts',
                'type'           => 'text'
            )
        )
   );   
    
   $wp_customize->add_setting('footer_col_select', array(
	'default'     => '1',
	'sanitize_callback' => 'sanitize_text',
));
$wp_customize->add_control(new footer_Select_Custom_Control($wp_customize, 'footer_col_select', array(
	'label'     	=> esc_attr__( 'Footer layout', 'squiggle' ),
	'description'   => esc_attr__( 'Choose a layout for your Footer', 'squiggle' ),
	'settings'  	=> 'footer_col_select',
	'section'   	=> 'custom_footer_text',
)));
    

    
    
  // Create custom panels
  $wp_customize->add_panel( 'general_settings', array(
      'priority' => 10,
      'theme_supports' => '',
      'title' => __( 'General Settings', 'squiggle' ),
      'description' => __( 'Controls the basic settings for the theme.', 'squiggle' ),
  ) );
  $wp_customize->add_panel( 'design_settings', array(
      'priority' => 20,
      'theme_supports' => '',
      'title' => __( 'Design Settings', 'squiggle' ),
      'description' => __( 'Controls the basic design settings for the theme.', 'squiggle' ),
  ) ); 
    
    // RTL style
    
    
  $wp_customize->add_section( 'sq_rtl_secton' , array(
    'title'      => __('RTL Settings (Right to left)','squiggle'), 
  ) );   
    
$wp_customize->add_setting('sq_rtl_setting', array(
	'default'     => false,
	'sanitize_callback' => 'sanitize_text',
));
 $wp_customize->add_control(
        new Toggle_Checkbox_Custom_control(
            $wp_customize,
            'sq_hide_blog_ctr',
            array(
                'description'    =>    __( 'Use RTL (Right to left [rtl.css])' , 'squiggle' ),
                'label'    =>    __( 'Check here', 'squiggle'),
                'section'  => 'sq_rtl_secton',
                'settings' => 'sq_rtl_setting',
                'type'     => 'checkbox'
            )
        )
   );  
    
    
  // Assign sections to panels
  $wp_customize->get_section('title_tagline')->panel = 'general_settings';      
  //$wp_customize->get_section('nav')->panel = 'general_settings';
  $wp_customize->get_section('static_front_page')->panel = 'general_settings';
  //$wp_customize->get_section('header_text_styles')->panel = 'design_settings';
  $wp_customize->get_section('background_image')->panel = 'design_settings';
  $wp_customize->get_section('background_image')->priority = 1000;
  //$wp_customize->get_section('header_image')->panel = 'design_settings';  

}
add_action( 'customize_register', 'wpt_register_theme_customizer' );


// Add theme support for Custom Header Image

$defaults = array(
  'default-image'          => ' ', 
  'default-text-color'     => ' ',
  'header-text'            => true,
  'uploads'                => true,
  'wp-head-callback'       => 'wpt_style_header'
);
add_theme_support( 'custom-header', $defaults );


// Converting get_theme_mod into variables for easy acess and use

function wpt_style_header() {

  $nav_text_background = get_theme_mod('sq_nav_design_settings_background');
  $nav_text_dropdown_background = get_theme_mod('sq_nav_design_settings_dropdown_background');
  $nav_text_color = get_theme_mod('sq_nav_design_settings');
  $nav_text_color_hover = get_theme_mod('sq_nav_design_settings_hover');
  $nav_text_color_boder = get_theme_mod('sq_nav_design_settings_boder');
  $nav_text_color_boder_style = get_theme_mod('sq_nav_design_settings_boder_style');
  $sq_h1_styles = get_theme_mod('sq_h1_color');
  $sq_h1_styles_h1 = get_theme_mod('sq_h1_font_size');
  $nav_2_background = get_theme_mod('sq_nav_2_design_settings_background');
  $nav_2_color = get_theme_mod('sq_nav_2_design_settings_color');
  $nav_2_color_hover = get_theme_mod('sq_nav_2_design_settings_color_hover');
  $nav_2_color_submenu = get_theme_mod('sq_nav_2_design_settings_color_submenu');
  $sq_p_select_font = get_theme_mod('sq_p_color');
  $sq_p_select_color = get_theme_mod('sq_p_font_size');
  $sq_nav_sitename = get_theme_mod('sq_nav_design_settings_sitename_color');
  $sq_nav_description = get_theme_mod('sq_nav_design_settings_description_color');    
  $sq_general_p_font = get_theme_mod( 'sq_general_p_font', "" );
  $sq_general_h_font = get_theme_mod( 'sq_general_h_font', "" );  
  
  ?>
<?php 
    $font_styles = ':300,400,600,700,800,900,300italic,400italic,600italic,700italic,800italic,900italic';
    if ( $sq_general_p_font != "" )
	{
		echo '<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=' . $sq_general_p_font . $font_styles . $subset . '">';
	} 
    ?>
<?php if ( $sq_general_h_font != "" )
	{
		echo '<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=' . $sq_general_h_font . $font_styles . $subset . '">';
	} 
    ?>
<style type="text/css">
    @media only screen and (min-width: 480px) {
        <?php if(get_theme_mod('sq_allow_inlinepost_ads_position')==1): ?>.inpost-ads img {
            width: 300px;
            height: 250px;
            float: left;
            margin-right: 27px;
        }
        <?php endif;
        ?><?php if(get_theme_mod('sq_allow_inlinepost_ads_position')==2): ?>.inpost-ads img {
            width: 300px;
            height: 250px;
            float: right;
            margin-left: 27px;
        }
        <?php endif;
        ?>
    }

    <?php if(get_theme_mod('sq_nav_design_bg_trans', true)==true): ?>.pc-menu-inner,
    .mobile-menu-inner-element {
        background: transparent !important;
    }

    <?php endif;
    ?>@media only screen and (min-width: 767px) {
        <?php if(get_theme_mod('image_options')==2): ?>.col-md-12.no-padding.clearfix .col-md-8.col-sm-8 {
            float: right;
        }
        <?php endif;
        ?><?php if(get_theme_mod('image_options')==1): ?>.col-md-12.no-padding.clearfix .col-md-8.col-sm-8 {
            float: left !important;
        }
        <?php endif;
        ?>
    }

    <?php if (get_theme_mod('sq_nav_design_show_border')==false) {
        ?>.pc-menu-inner {
            border-top-width: 1px;
            border-bottom-width: 1px;
        }
        <?php
    }

    else {
        ?>.pc-menu-inner {
            border: 0px;
        }
        <?php
    }

    ?>.pc-menu-inner {
        background: <?php echo esc_attr( $nav_text_background);
        ?>;
    }

    html,
    button,
    input,
    select,
    textarea,
    p,
    span,
    div,
    li,
    ol,
    ul,
    text,
    .the-main-post-content li,
    .share-buttons,
    input[type="button"],
    input[type="reset"],
    input[type="submit"],
    .even-more-sq-rt.even-more-post-visible h3,
    .the-big-grid-1-meta h2,
    .the-big-grid-2-meta h2 {
        <?php if ( get_theme_mod('sq_p_custom_font', 1)==1) {
            ?>font-family: 'open sans', sans-serif;
            <?php
        }
        else {
            ?>font-family: '<?php echo get_theme_mod('sq_p_custom_font' ); ?>', sans-serif;
            <?php
        }
        ?>
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    .Squiggle-button,
    .footer-tagline,
    input#submit,
    .widget-inner li,
    .widget-inner ul,
    .widget-inner ol {
        <?php if ( get_theme_mod('sq_heading_custom_font', 'Coustard')=='Coustard') {
            ?>font-family: 'coustard', sans-serif;
            <?php
        }
        else {
            ?>font-family: '<?php echo get_theme_mod('sq_heading_custom_font' ); ?>', sans-serif;
            <?php
        }
        ?>
    }

    p {
        color: <?php echo esc_attr( $sq_p_select_font);
        ?>!important;
        font-size: <?php echo ( $sq_p_select_color);
        ?>!important;
    }

    .text-mobile-menu-text.text-center h2 a {
        color: <?php echo esc_attr( $sq_nav_description);
        ?>;
    }

    .text-mobile-menu-text.text-center p,
    .mobile-menu-inner.text-center span,
    .mobile-menu-inner.text-center .fa {
        color: <?php echo esc_attr( $sq_nav_sitename);
        ?>!important;
    }

    .squiggle-wp-main-nav {
        background: <?php echo esc_attr( $nav_2_background);
        ?>;
    }

    .squiggle-wp-main-nav li a {
        color: <?php echo esc_attr( $nav_2_color);
        ?>!important;
    }

    .squiggle-wp-main-nav ul ul {
        background: <?php echo esc_attr( $nav_2_color_submenu);
        ?>!important;
    }

    .squiggle-wp-main-nav li:hover>a {
        color: <?php echo esc_attr( $nav_2_color_hover);
        ?>!important;
    }

    .pc-menu-inner ul li a,
    .mobile-menu-inner-element ul li a,
    .toggle-menu .toggle-caret .fa {
        color: <?php echo esc_attr( $nav_text_color);
        ?>;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    .main-post-loop-2-meta h2 a {
        color: <?php echo esc_attr( $sq_h1_styles);
        ?>!important;
    }

    @media only screen and (min-width: 780px) {
        h1 {
            font-size: <?php echo esc_attr( $sq_h1_styles_h1);
            ?>!important;
        }
    }

    .pc-menu-inner ul li a:hover,
    .mobile-menu-inner-element ul li a:hover,
    .toggle-menu .toggle-caret .fa:focus {
        color: <?php echo esc_attr( $nav_text_color_hover);
        ?>;
    }

    .pc-menu-inner,
    .mobile-menu-inner.text-center,
    .mobile-menu-inner-element {
        border-color: <?php echo esc_attr( $nav_text_color_boder);
        ?>;
    }

    .pc-menu-inner {
        border-top-style: <?php echo esc_attr( $nav_text_color_boder_style);
        ?>;
        border-bottom-style: <?php echo esc_attr( $nav_text_color_boder_style);
        ?>;
    }

    @media only screen and (min-width: 992px) {
        .pc-menu-inner .sub-menu {
            background: <?php echo esc_attr( $nav_text_dropdown_background);
            ?>!important;
        }
    }

    h1 {
        font-size: <?php echo get_theme_mod('wpt_h1_font_size');
        ?>;
    }

    h1 a {
        color: <?php echo get_theme_mod('wpt_h1_color');
        ?>;
    }

    <?php if( get_theme_mod('wpt_custom_css') !='') {
        echo get_theme_mod('wpt_custom_css');
    }

    ?><?php if ( $sq_general_p_font !="") {
        echo 'html,
 button,
        input,
        select,
        textarea,
        p,
        span,
        div,
        li,
        ol,
        ul,
        text,
        .the-main-post-content li,
        .share-buttons,
        input[type="button"],
        input[type="reset"],
        input[type="submit"],
        .even-more-sq-rt.even-more-post-visible h3 {
            font-family: "' . $sq_general_p_font . '", Georgia, serif;
        }
        ' . "\n";

    }

    ?><?php if ( $sq_general_h_font !="") {
        echo 'html,
 h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .Squiggle-button,
        .footer-tagline,
        input#submit,
        .widget-inner li,
        .widget-inner ul,
        .widget-inner ol {
            font-family: "' . $sq_general_h_font . '", Georgia, serif;
        }
        ' . "\n";

    }

    ?>

</style>
<?php 

}


// Add theme support for Custom Backgrounds
$defaults = array(
  'default-color' => '#fff',
  //'default-image' => get_template_directory_uri() . '/images/background.png',  
);
add_theme_support( 'custom-background', $defaults );


// Sanitize text 
function sanitize_text( $text ) {
    return sanitize_text_field( $text );
}

// Sanitize textarea 
function sanitize_textarea( $text ) {
    return esc_textarea( $text );
}


// Custom js for theme customizer
function wpt_customizer_js() {
  wp_enqueue_script(
    'wpt_theme_customizer',
    get_template_directory_uri() . '/asset/js/theme-customizer.js',
    array( 'jquery', 'customize-preview' ),
    '',
    true
);
}
add_action( 'customize_preview_init', 'wpt_customizer_js' );    

/* 
* Extending the customizer interface
* Creating new settings with inbuilt control
*/

if (class_exists('WP_Customize_Control')){
class Toggle_Checkbox_Custom_control extends WP_Customize_Control{
	public $type = 'toogle_checkbox';
	public function render_content(){
		?>
<div class="checkbox_switch">
    <p>
        <?php echo wp_kses_post($this->description); ?>
    </p>
    <div class="onoffswitch">
        <input type="checkbox" id="<?php echo esc_attr($this->id); ?>" name="<?php echo esc_attr($this->id); ?>" class="onoffswitch-checkbox" value="<?php echo esc_attr( $this->value() ); ?>" <?php $this->link(); checked( $this->value() ); ?>>
        <label class="onoffswitch-label" for="<?php echo esc_attr($this->id); ?>"></label>
    </div> <span class="customize-control-title onoffswitch_label"><?php echo esc_html( $this->label ); ?></span> </div>
<?php
	}
}
    
class Image_Select_Custom_Control extends WP_Customize_Control{
	public $type = 'image_select';
    public function enqueue(){
		wp_enqueue_style( 'custom_controls_css', get_template_directory_uri().'/inc/customizer/css/customizer-style.css');
	}
	public function render_content(){
	?>
    <div class="customize_image_select"> <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
        <p>
            <?php echo wp_kses_post($this->description); ?>
        </p>
        <label>
                            <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="1" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '1', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/2cr.png'?>" alt="<?php esc_attr_e('Default - right sidebar', 'squiggle'); ?>" title="<?php esc_attr_e('Option 1', 'squiggle'); ?>" /> </label>
        <label>
                            <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="2" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '2', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/2cl.png'?>" alt="<?php esc_attr_e('left sidebar', 'squiggle'); ?>" title="<?php esc_attr_e('Option 2', 'squiggle'); ?>" /> </label>
        <label>
                            <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="3" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '3', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/1c.png'?>" alt="<?php esc_attr_e('Option 3', 'squiggle'); ?>" title="<?php esc_attr_e('fullwidth - no sidebar', 'squiggle'); ?>" /> </label>
    </div>
    <?php
	}
}
    

class Nav_Select_Custom_Control extends WP_Customize_Control{
	public $type = 'nav_type_select';
	public function render_content(){
	?>
        <div class="customize_image_select"> <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <p>
                <?php echo wp_kses_post($this->description); ?>
            </p>
            <label>
                                <h3 style="text-align: center;"> Navigtion style 1</h3>
                                <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="1" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '1', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/nav-1.png'?>" alt="<?php esc_attr_e('Default - right sidebar', 'squiggle'); ?>" title="<?php esc_attr_e('Navigation style 1', 'squiggle'); ?>" /> </label>
            <label>
                                <h3 style="text-align: center;"> Navigtion style 2 </h3>
                                <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="2" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '2', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/nav-2.png'?>" alt="<?php esc_attr_e('left sidebar', 'squiggle'); ?>" title="<?php esc_attr_e('Navigation style 2', 'squiggle'); ?>" /> </label>
            <div class="nav-style-comming-soon">
                <label>
                                    <h3 style="text-align: center;"> Navigtion style 3 </h3>
                                    <input disabled="disabled" type="radio" name="<?php echo esc_attr($this->id); ?>" value="3" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '3', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/nav-3.png'?>" alt="<?php esc_attr_e('left sidebar', 'squiggle'); ?>" title="<?php esc_attr_e('Navigation style 3', 'squiggle'); ?>" /> </label>
            </div>
        </div>
        <?php
	}
}
    
class footer_Select_Custom_Control extends WP_Customize_Control{
	public $type = 'footer_col_select';
	public function render_content(){
	?>
            <div class="customize_image_select"> <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <p>
                    <?php echo wp_kses_post($this->description); ?>
                </p>
                <label>
                                    <h3 style="text-align: center;"> Footer style 1</h3>
                                    <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="1" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '1', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/f1.png'?>" alt="<?php esc_attr_e('Default - 1 column', 'squiggle'); ?>" title="<?php esc_attr_e('Footer style 1', 'squiggle'); ?>" /> </label>
                <label>
                                    <h3 style="text-align: center;"> Footer style 2 </h3>
                                    <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="2" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '2', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/f2.png'?>" alt="<?php esc_attr_e('2 column', 'squiggle'); ?>" title="<?php esc_attr_e('footer style 2', 'squiggle'); ?>" /> </label>
                <div class="nav-style-comming-soon">
                    <label>
                                        <h3 style="text-align: center;"> Footer style 3 </h3>
                                        <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="3" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '3', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/f3.png'?>" alt="<?php esc_attr_e('3 column', 'squiggle'); ?>" title="<?php esc_attr_e('footer style 3', 'squiggle'); ?>" /> </label>
                </div>
            </div>
            <?php
	}
}
    

class post_Select_Custom_Control extends WP_Customize_Control{
	public $type = 'post_layout_options';
	public function render_content(){
	?>
                <div class="customize_image_select"> <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                    <p>
                        <?php echo wp_kses_post($this->description); ?>
                    </p>
                    <label>
                                        <h3 style="text-align: center;"> Post style 1</h3>
                                        <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="1" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '1', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/ps-1.png'?>" alt="<?php esc_attr_e('Default - 1 column', 'squiggle'); ?>" title="<?php esc_attr_e('Footer style 1', 'squiggle'); ?>" /> </label>
                    <label>
                                        <h3 style="text-align: center;"> Post style 2 </h3>
                                        <input type="radio" name="<?php echo esc_attr($this->id); ?>" value="2" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '2', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/ps-2.png'?>" alt="<?php esc_attr_e('2 column', 'squiggle'); ?>" title="<?php esc_attr_e('footer style 2', 'squiggle'); ?>" /> </label>
                    <label>
                                        <h3 style="text-align: center;"> Post style 3 </h3>
                                        <input disabled="disabled" type="radio" name="<?php echo esc_attr($this->id); ?>" value="3" data-customize-setting-link="<?php echo esc_attr($this->id); ?>" <?php checked( '3', esc_attr($this->value()) );?>/> <img src="<?php echo get_template_directory_uri().'/asset/img/layout/ps-3.png'?>" alt="<?php esc_attr_e('3 column', 'squiggle'); ?>" title="<?php esc_attr_e('footer style 3', 'squiggle'); ?>" /> </label>
                </div>
                <?php
	}
}
    
}

?>
