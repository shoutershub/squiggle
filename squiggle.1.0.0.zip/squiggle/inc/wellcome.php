<?php
/**
 * Theme Welcome
 *
 * @description: Adds a welcome message pointer when the user activates the theme
 * @sources:
 * https://wordimpress.com/create-wordpress-theme-activation-popup-message/
 * http://www.wpexplorer.com/making-themes-plugins-more-usable/
 */
 
function sq_wellcome_note( $hook_suffix ) {
 
	// Assume pointer shouldn't be shown
	$enqueue_pointer_script_style = false;
 
	// Get array list of dismissed pointers for current user and convert it to array
	$dismissed_pointers = explode( ',', get_user_meta( get_current_user_id(), 'dismissed_wp_pointers', true ) );
 
	// Check if our pointer is not among dismissed ones
	if( !in_array( 'sq_settings_pointer', $dismissed_pointers ) ) {
		$enqueue_pointer_script_style = true;
 
		// Add footer scripts using callback function
		add_action( 'admin_print_footer_scripts', 'sq_pointer_print_scripts' );
	}
 
	// Enqueue pointer CSS and JS files, if needed
	if( $enqueue_pointer_script_style ) {
		wp_enqueue_style( 'wp-pointer' );
		wp_enqueue_script( 'wp-pointer' );
	}
 
}
add_action( 'admin_enqueue_scripts', 'sq_wellcome_note' );
 
function sq_pointer_print_scripts() {
 
    $pointer_content = '<h3>'.__('Awesomeness!', 'squiggle' ).'</h3>';
    $pointer_content .= '<p>'.__('You have just Installed Squiggle WordPress Theme by Foreigncodes.', 'squiggle' ).'</p>';
	$pointer_content .= '<p>'.wp_kses(__('You can Trigger The Awesomeness using Amazing Option Panel in <strong>Wordpress Default customizer panel</strong>.', 'squiggle' ), array( 'strong' => '' ) ).'</p>';
    $pointer_content .= '<p>'.__('If you face any problem, head over to', 'squiggle' ).' <a href="http://foreigncodes.com/forums/forum/">'.__('Support Forums', 'squiggle' ).'</a></p>';
    
	?>
 
	<script type="text/javascript">
	//<![CDATA[
	jQuery(document).ready( function($) {
		$('#menu-appearance').pointer({
			content:		'<?php echo $pointer_content; ?>',
			position:		{
								edge:	'left', // arrow direction
								align:	'center' // vertical alignment
							},
			pointerWidth:	350,
			close:			function() {
								$.post( ajaxurl, {
										pointer: 'sq_settings_pointer', // pointer ID
										action: 'dismiss-wp-pointer'
								});
							}
		}).pointer('open');
	});
	//]]>
	</script>
 
<?php
}