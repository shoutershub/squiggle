<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Squiggle
 */

?>
    <div class="footer-section col-md-12 clearfix">
        <?php
$footer_secletor =  get_theme_mod('footer_col_select');
switch($footer_secletor){
        case 1:
          include_once get_template_directory() . '/template-parts/layouts/footer-1.php';
        break;    
    case 2:
        include_once get_template_directory() . '/template-parts/layouts/footer-2.php';
        break;
    case 3:
        include_once get_template_directory() . '/template-parts/layouts/footer-3.php';
        break;
    default:
        include_once get_template_directory() . '/template-parts/layouts/footer-1.php';
} 
   ?>
    </div>
    </div> <!--#content closing tag @ header.php -->
    </div> <!--.container closing tag @ header.php-->
    </div> <!--.squiggle-main-sect closing tag @ header.php-->
    </div> <!-- .site closing tag @ header.php -->
    <?php wp_footer(); ?>
    </body>

    </html>
